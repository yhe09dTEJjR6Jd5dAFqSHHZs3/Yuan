import sys
sys.dont_write_bytecode = True
import os
import math
import re
import json
import time
import uuid
import queue
import shutil
import signal
import sqlite3
import hashlib
import tempfile
import threading
import subprocess
import platform
import types
import copy
import urllib.request
import urllib.parse
from pathlib import Path
from collections import deque
from contextlib import contextmanager

APP_NAME = "Yuan"
STATE_NAME = f".{APP_NAME.lower()}-native-audio-6"
PYTHON_REQUIREMENT = ">=3.10"
PACKAGES = (
    "numpy>=1.26", "sounddevice>=0.5", "soundfile>=0.13", "soxr>=0.5", "psutil>=5.9", "certifi>=2024"
)
TEXT = {
    "title": ("让声音，直接抵达。", "A direct connection. Through voice."),
    "subtitle": ("提示词 + 处理后的音频 → AI 模型 → 音频", "Prompt + processed audio → AI model → audio"),
    "choose": ("选择文件夹", "Choose folder"),
    "folder": ("工作目录", "Workspace"),
    "empty_folder": ("选择后自动准备环境与模型", "Choose a folder to prepare everything automatically"),
    "prompt": ("提示词", "Instructions"),
    "default_prompt": ("你是 Yuan。请用自然、清晰的中文进行语音对话，认真回应用户。", "You are Yuan. Have a natural, clear spoken conversation in English and respond thoughtfully."),
    "start": ("开始对话", "Start conversation"),
    "stop": ("结束对话", "End conversation"),
    "confirm_title": ("确认结束", "Confirm ending"),
    "confirm_stop": ("确认结束本次对话？", "End this conversation?"),
    "confirm_close": ("确认结束本次对话并关闭 Yuan？", "End this conversation and close Yuan?"),
    "idle": ("等待开始", "Ready when you are"),
    "setup": ("正在自动准备", "Preparing automatically"),
    "runtime": ("准备独立运行环境", "Preparing an isolated runtime"),
    "download": ("下载并校验运行组件", "Downloading and verifying components"),
    "loading": ("装载 Yuan 自建音频模型", "Loading Yuan’s self-built audio model"),
    "checking": ("正在验证模型音频链路", "Checking the model audio pipeline"),
    "ready": ("运行环境已就绪", "Runtime is ready"),
    "connecting": ("正在连接麦克风与扬声器", "Connecting the microphone and speaker"),
    "listening": ("我在听", "I'm listening"),
    "thinking": ("正在生成实验音频", "Generating experimental audio"),
    "speaking": ("Yuan 正在说话", "Yuan is speaking"),
    "ending": ("正在结束本次对话", "Ending this conversation"),
    "ended": ("本次对话已结束", "Conversation ended"),
    "training": ("空闲学习 · 原生音频预测", "Idle learning · native audio prediction"),
    "validating": ("分组留出验证 · 尚未启用候选权重", "Group-held-out validation · candidate not active"),
    "promoted": ("独立音频验证改善 · 新权重已启用", "Independent audio validation improved · weights activated"),
    "kept": ("未通过全部验证 · 候选继续学习", "Validation not passed · candidate keeps learning"),
    "waiting_data": ("等待独立音频样本", "Waiting for independent audio samples"),
    "network": ("空闲联网获取公开音频", "Fetching public audio while idle"),
    "offline": ("公开音频源暂不可达 · 本地学习继续", "Public audio source unreachable · local learning continues"),
    "paused": ("学习暂缓 · 对话不受影响", "Learning paused · conversation remains available"),
    "retry": ("等待条件恢复 · 自动重试", "Waiting for recovery · retrying automatically"),
    "failure": ("当前条件未能完成准备", "Preparation could not complete under current conditions"),
    "devices": ("设备", "Devices"),
    "model": ("模型与链路", "Model and pipeline"),
    "audio": ("音频", "Audio"),
    "learning": ("持续学习", "Continuous learning"),
    "storage": ("本地存储", "Local storage"),
    "resources": ("实时资源", "Live resources"),
    "privacy": ("语音和提示词仅存入所选目录，不上传；空闲时下载公开音频。系统驱动可能产生目录外缓存。", "Voice and instructions stay in the selected folder and are not uploaded. Public audio downloads run while idle. System drivers may create external caches."),
    "full_duplex": ("持续收音 · 生成和播放期间仍在听", "Continuous input · listening during generation and playback"),
    "barge_in": ("检测到新语音 · 已取消当前回复", "New speech detected · current reply cancelled"),
    "capture_saved": ("语音片段已保存", "Speech segment saved"),
    "capture_gap": ("收音发生缺口 · 已隔离受影响的训练样本", "Capture gap · affected training samples quarantined"),
    "capture_recover": ("收音设备恢复中 · 将自动重连", "Recovering audio capture · reconnecting automatically"),
    "echo_note": ("基础回声抑制 · 播放重叠片段不作训练目标；建议耳机", "Basic echo suppression · playback-overlap segments excluded from training; headphones recommended"),
    "capture_stopped": ("收音已停止 · 尾部语音已处理", "Capture stopped · trailing speech processed"),
    "capture_wait": ("正在完成尾部语音存档", "Finishing trailing speech storage"),
    "audio_policy": ("自适应音频参数", "Adaptive audio settings"),
    "candidate_reset": ("候选数值异常 · 已回退到有效存档", "Non-finite candidate · reverting to a valid checkpoint"),
    "pending": ("待处理片段", "Pending segments"),
    "excluded": ("不作训练目标", "Excluded from targets"),
    "closed": ("正在释放运行资源", "Releasing runtime resources"),
    "no_prompt": ("已自动填入默认提示词", "Default instructions filled in automatically"),
    "limited": ("资源长度边界已到 · 本轮已安全结束", "Resource length limit reached · turn ended safely"),
    "metrics_note": ("自建模型从零训练；声学损失下降不代表能听懂、会说话或具备知识。未经独立音频验证，不播放随机权重输出。", "This self-built model trains from scratch. Lower acoustic loss does not establish speech, understanding or knowledge. Random-weight output is not played before independent audio validation."),
    "mic_missing": ("等待可用麦克风与扬声器", "Waiting for a microphone and speaker"),
    "history_full": ("存储空间不足 · 暂停保存新增历史", "Storage low · new history recording paused"),
    "input": ("输入", "Input"), "output": ("输出", "Output"),
    "seconds": ("秒", "seconds"), "turns": ("轮", "turns"),
    "local": ("本地", "Local"), "public": ("公开音频", "Public audio"),
    "steps": ("训练步数", "Training steps"),
    "accepted": ("已验证更新", "Validated updates"), "before": ("验证前", "Before"),
    "after": ("验证后", "After"), "wait": ("等待", "Waiting"),
    "available": ("可用", "Available"),
    "input_faults": ("收音异常", "Input faults"), "output_faults": ("播放异常", "Output faults"),
    "playback_gap": ("播放出现间断 · 收音继续", "Playback discontinuity · input remains active"),
    "checkpointing": ("保存候选学习进度", "Saving candidate learning progress"),
    "checkpoint_saved": ("学习进度已保存", "Learning progress saved"),
    "command_failed": ("控制通道中断 · 正在恢复", "Control channel interrupted · recovering"),
    "runtime_profile": ("运行环境与组件版本", "Runtime environment and component versions"),
    "elapsed": ("本次对话", "Session"),
    "queued": ("对话已排队 · 准备完成后自动开始", "Conversation queued · starts automatically when ready"),
    "prefill": ("提示词 + 音频直接进入 Yuan 模型", "Prompt + audio entering the Yuan model directly"),
    "generating": ("Yuan 模型直接生成音频", "Yuan model generating audio directly"),
    "activity": ("实时运行记录", "Live activity"),
    "all_activity": ("完整记录", "Full activity"),
    "older": ("较早", "Earlier"), "newer": ("较新", "Later"), "live": ("实时", "Live"),
    "runtime_message": ("运行组件反馈", "Runtime component feedback"),
    "journal_failure": ("记录写入失败 · 界面反馈继续", "Activity storage failed · live feedback continues"),
    "backoff": ("自动恢复倒计时", "Automatic recovery countdown"),
    "pipeline_ok": ("音频链路通过 · 对话能力未经验证", "Audio pipeline passed · conversation ability unverified"),
    "history_context": ("使用历史提示词与音频上下文；生成音频不作目标", "Using historical prompts and audio context; generated audio is not a target"),
    "memory_pause": ("内存余量不足 · 暂停学习并自动复查", "Memory headroom is low · learning paused with automatic checks"),
    "source_skipped": ("公开音频暂不适用", "Public audio is not currently usable"),
    "recovered": ("运行条件已恢复", "Runtime conditions recovered"),
    "recording_resumed": ("运行记录写入已恢复", "Activity recording has resumed"),
    "resource_failure": ("资源监测暂不可用", "Resource monitoring is temporarily unavailable"),
    "learn_yield": ("学习已暂停，优先对话", "Learning yielded to conversation"),
    "started": ("对话已开始", "Conversation started"),
    "turn": ("本轮对话完成", "Turn completed"),
    "source": ("公开音频来源与许可", "Public audio source and license"),
    "pipeline": ("音频链路检查", "Audio pipeline check"),
    "progress": ("准备进度", "Preparation progress"),
    "metrics": ("资源监测", "Resource measurements"),
    "notice": ("运行提示", "Runtime notice"),
    "error": ("运行异常", "Runtime error"),
    "exit": ("音频进程已退出", "Audio process exited"),
    "disconnected": ("音频进程已断开", "Audio process disconnected"),
    "launcher_closed": ("工作目录资源已释放", "Workspace resources released"),
    "cold_start": ("自建模型冷启动 · 正在积累真实音频，尚无已验证对话能力", "Self-built model cold start · collecting real audio; conversation ability is unverified"),
    "experimental": ("实验音频模型 · 声学更新已验证，语音对话能力仍未经验证", "Experimental audio model · acoustic updates validated; spoken conversation remains unverified"),
    "collecting": ("录音已保存 · 结束对话后学习；尚无可播放的已验证权重", "Recording saved · learning resumes after the session; no validated weights are available for playback"),
    "training_unvalidated": ("候选持续训练 · 等待独立验证与保护样本", "Candidate is training · waiting for independent validation and guard samples"),
    "candidate_recovered": ("已恢复未启用的候选训练状态", "Inactive candidate training state restored"),
    "checkpoint_failure": ("模型存档无效 · 未装载损坏权重", "Invalid model checkpoint · damaged weights were not loaded"),
    "device_fallback": ("加速设备不可用 · 改用 CPU", "Accelerator unavailable · using CPU"),
    "sample_skipped": ("音频样本暂不可学习 · 已保留来源记录", "Audio sample is not learnable · provenance retained"),
    "source_catalog": ("公开音频目录", "Public audio catalog"),
    "no_display": ("当前设备没有可用的图形界面。", "No graphical display is available on this device."),
}

class Cancelled(Exception):
    pass

class YuanError(RuntimeError):
    pass

def tick():
    return max(sys.getswitchinterval(), time.get_clock_info("monotonic").resolution)

def check(cancel):
    if cancel is not None and cancel.is_set():
        raise Cancelled()

def tr(key, language="中文"):
    value = TEXT.get(key)
    if value:
        return value[language == "English"]
    return str(key)

def human_bytes(value):
    value = max(0.0, float(value))
    units = ("B", "KiB", "MiB", "GiB", "TiB", "PiB")
    for unit in units:
        if value < 1024 or unit == units[-1]:
            return f"{value:.1f} {unit}"
        value /= 1024

def local_message(value, language):
    parts = str(value).split(" / ", 1)
    return parts[-1] if language == "English" else parts[0]

def safe_path(root, relative):
    root = Path(root).resolve()
    value = str(relative)
    if not value or "\\" in value or ":" in value or "\x00" in value:
        raise YuanError("目录路径无效 / Invalid workspace path")
    path = (root / value).resolve()
    if path == root or root not in path.parents:
        raise YuanError("拒绝访问工作目录以外的路径 / Refusing a path outside the workspace")
    return path

def database_path(root, name):
    path = safe_path(root, name)
    for suffix in ("", "-wal", "-shm", "-journal"):
        candidate = Path(root) / (name + suffix)
        if candidate.is_symlink():
            raise YuanError("拒绝使用链接数据库文件 / Refusing a linked database file")
        safe_path(root, name + suffix)
    return path

def sync_dir(path):
    if os.name != "nt":
        try:
            fd = os.open(str(path), os.O_RDONLY)
            try:
                os.fsync(fd)
            finally:
                os.close(fd)
        except OSError:
            pass

def atomic_json(path, payload, cancel=None):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(dir=path.parent, prefix=".write-", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            json.dump(payload, stream, ensure_ascii=False, allow_nan=False, separators=(",", ":"))
            stream.flush()
            os.fsync(stream.fileno())
        check(cancel)
        os.replace(name, path)
        sync_dir(path.parent)
    finally:
        if os.path.exists(name):
            os.unlink(name)

def read_json(path, default=None):
    try:
        with Path(path).open(encoding="utf-8") as stream:
            value = json.load(stream)
            return value if isinstance(value, dict) else ({} if default is None else default)
    except (OSError, ValueError, TypeError):
        return {} if default is None else default

def digest_file(path, cancel=None, algorithm="sha256"):
    path = Path(path)
    value = hashlib.new(algorithm)
    with path.open("rb") as stream:
        while True:
            check(cancel)
            part = stream.read(os.statvfs(path.parent).f_bsize * 256 if hasattr(os, "statvfs") else 1024 * 1024)
            if not part:
                break
            value.update(part)
    return value.hexdigest()

class WorkspaceLease:
    def __init__(self, path):
        self.stream = None
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        if path.is_symlink():
            raise YuanError("拒绝使用链接锁文件 / Refusing a linked lock file")
        stream = path.open("a+b")
        try:
            if os.name == "nt":
                import msvcrt
                if path.stat().st_size == 0:
                    stream.write(b"\0")
                    stream.flush()
                stream.seek(0)
                msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            self.stream = stream
        except Exception:
            stream.close()
            raise YuanError("另一个 Yuan 正在使用此目录 / Another Yuan is using this workspace")

    def close(self):
        stream, self.stream = self.stream, None
        if stream is None:
            return
        try:
            if os.name == "nt":
                import msvcrt
                stream.seek(0)
                msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(stream.fileno(), fcntl.LOCK_UN)
        finally:
            stream.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

def workspace_environment(workspace):
    workspace = Path(workspace).resolve()
    state = safe_path(workspace, STATE_NAME)
    cache = safe_path(state, "cache")
    values = {
        "HOME": state / "home", "USERPROFILE": state / "home",
        "APPDATA": state / "config" / "roaming", "LOCALAPPDATA": state / "config" / "local",
        "TORCH_HOME": cache / "torch", "TORCH_EXTENSIONS_DIR": cache / "torch-extensions",
        "TRITON_CACHE_DIR": cache / "triton", "TORCHINDUCTOR_CACHE_DIR": cache / "inductor", "CUDA_CACHE_PATH": cache / "cuda",
        "XDG_CACHE_HOME": cache / "xdg", "XDG_CONFIG_HOME": state / "config", "XDG_DATA_HOME": state / "data", "XDG_STATE_HOME": state / "state",
        "UV_CACHE_DIR": cache / "uv", "UV_PYTHON_INSTALL_DIR": state / "python", "UV_TOOL_DIR": state / "tools",
        "UV_TOOL_BIN_DIR": state / "bin", "UV_PYTHON_BIN_DIR": state / "bin", "PIP_CACHE_DIR": cache / "pip",
        "TMPDIR": state / "temp", "TEMP": state / "temp", "TMP": state / "temp",
    }
    env = os.environ.copy()
    for key in ("PYTHONPATH", "PYTHONHOME", "VIRTUAL_ENV", "PIP_TARGET", "PIP_PREFIX", "PIP_USER"):
        env.pop(key, None)
    for key, path in values.items():
        path = safe_path(state, path.relative_to(state).as_posix())
        path.mkdir(parents=True, exist_ok=True)
        env[key] = str(path)
    env.update({
        "YUAN_WORKSPACE": str(workspace), "PYTHONNOUSERSITE": "1", "PYTHONDONTWRITEBYTECODE": "1", "PYTHONUNBUFFERED": "1",
        "PYTHONUTF8": "1", "PYTHONIOENCODING": "utf-8", "PIP_NO_COMPILE": "1", "UV_COMPILE_BYTECODE": "0",
        "PIP_DISABLE_PIP_VERSION_CHECK": "1", "PIP_NO_INPUT": "1", "PIP_CONFIG_FILE": os.devnull, "UV_NO_MODIFY_PATH": "1", "UV_PYTHON_INSTALL_BIN": "0",
    })
    return env

def runtime_python(path):
    return Path(path) / ("Scripts/python.exe" if os.name == "nt" else "bin/python")

def end_process(process):
    if process is None or process.poll() is not None:
        return
    try:
        if os.name == "nt":
            subprocess.run(["taskkill", "/PID", str(process.pid), "/T", "/F"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)
        else:
            os.killpg(process.pid, signal.SIGTERM)
    except (OSError, ProcessLookupError):
        process.terminate()
    try:
        process.wait(timeout=max(1.0, math.sqrt(os.cpu_count() or 1)))
    except subprocess.TimeoutExpired:
        try:
            if os.name != "nt":
                os.killpg(process.pid, signal.SIGKILL)
            else:
                process.kill()
        except OSError:
            pass
        process.wait()

def spawn(command, env, **kwargs):
    options = {"start_new_session": True} if os.name != "nt" else {"creationflags": subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.CREATE_NO_WINDOW}
    return subprocess.Popen(command, env=env, cwd=env["YUAN_WORKSPACE"], **options, **kwargs)

def run_command(command, env, cancel, progress=None):
    process = spawn(command, env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace")
    result = deque(maxlen=max(1, int(math.sqrt(4096))))
    updates = queue.Queue(maxsize=max(16, (os.cpu_count() or 1) * 2))
    def read():
        try:
            while True:
                line = process.stdout.readline(65536)
                if not line:
                    break
                while not cancel.is_set():
                    try:
                        updates.put(line.rstrip(), timeout=math.sqrt(tick()))
                        break
                    except queue.Full:
                        pass
                if cancel.is_set():
                    break
        finally:
            try:
                updates.put_nowait(None)
            except queue.Full:
                pass
    reader = threading.Thread(target=read, daemon=True)
    reader.start()
    try:
        while process.poll() is None or reader.is_alive() or not updates.empty():
            check(cancel)
            try:
                line = updates.get(timeout=math.sqrt(tick()))
            except queue.Empty:
                continue
            if line is not None:
                result.append(line)
                if progress:
                    progress(line)
        if process.returncode:
            raise YuanError("运行组件未能准备完成 / Runtime preparation failed: " + "\n".join(result))
        return "\n".join(result)
    finally:
        if process.poll() is None:
            end_process(process)
        process.stdout.close()
        reader.join(timeout=max(tick(), math.sqrt(tick())))

class RuntimeInstaller:
    def __init__(self, workspace, cancel, emit):
        self.workspace, self.cancel, self.emit = Path(workspace), cancel, emit
        self.state = safe_path(workspace, STATE_NAME)
        self.env = workspace_environment(workspace)

    def interpreter(self):
        if sys.version_info[:2] >= (3, 10):
            return sys.executable
        tools = self.state / "tools" / "uv"
        candidates = (tools / "bin" / "uv", tools / "Scripts" / "uv.exe", tools / "uv" / "uv", tools / "uv" / "uv.exe")
        executable = next((value for value in candidates if value.is_file()), None)
        if executable is None:
            tools.mkdir(parents=True, exist_ok=True)
            run_command([sys.executable, "-m", "pip", "install", "--only-binary=:all:", "--no-deps", "--target", str(tools), "uv"], self.env, self.cancel,
                        lambda line: self.emit("runtime_message", detail=line))
            executable = next((value for value in candidates if value.is_file()), None)
        if executable is None:
            raise YuanError("无法自动取得兼容 Python / Compatible Python could not be provisioned automatically")
        run_command([str(executable), "--no-config", "python", "install", PYTHON_REQUIREMENT], self.env, self.cancel,
                    lambda line: self.emit("runtime_message", detail=line))
        value = run_command([str(executable), "--no-config", "python", "find", "--managed-python", PYTHON_REQUIREMENT], self.env, self.cancel).strip().splitlines()[-1]
        resolved = Path(value).resolve()
        if Path(self.env["UV_PYTHON_INSTALL_DIR"]).resolve() not in resolved.parents or not resolved.is_file():
            raise YuanError("独立 Python 校验失败 / Managed Python validation failed")
        return str(resolved)

    def ensure(self):
        self.emit("status", key="runtime")
        runtime = safe_path(self.state, "runtime")
        python = runtime_python(runtime)
        signature = hashlib.sha256(json.dumps([PACKAGES, platform.system(), platform.machine(), PYTHON_REQUIREMENT, "torch>=2.5"]).encode()).hexdigest()
        marker = read_json(runtime / "ready.json")
        probe = "import torch,numpy,sounddevice,soundfile,soxr,psutil,certifi; assert torch.__version__ and numpy.__version__ and soundfile.__version__ and psutil.__version__"
        if python.is_file() and marker.get("signature") == signature:
            try:
                run_command([str(python), "-c", probe], self.env, self.cancel)
                return python
            except Cancelled:
                raise
            except Exception as exc:
                self.emit("notice", key="runtime", reason=concise_error(exc))
        usable_python = python.is_file()
        if usable_python:
            try:
                run_command([str(python), "-c", "import sys; assert sys.version_info >= (3, 10); import ensurepip"], self.env, self.cancel)
            except Cancelled:
                raise
            except Exception as exc:
                usable_python = False
                self.emit("notice", key="runtime", reason=concise_error(exc), component="interpreter_rebuild")
        if not usable_python:
            interpreter = self.interpreter()
            run_command([interpreter, "-m", "venv", "--clear", str(runtime)], self.env, self.cancel,
                        lambda line: self.emit("runtime_message", detail=line))
        base = [str(python), "-m", "pip", "install", "--only-binary=:all:", "--no-compile"]
        def report(line):
            if line:
                self.emit("runtime_message", detail=line)
        self.emit("status", key="download")
        run_command([*base, "torch>=2.5", *PACKAGES], self.env, self.cancel, report)
        run_command([str(python), "-c", probe], self.env, self.cancel)
        run_command([str(python), "-m", "pip", "check"], self.env, self.cancel)
        atomic_json(runtime / "ready.json", {"signature": signature}, self.cancel)
        return python

class HTTPSOnly(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, fp, code, message, headers, newurl):
        if urllib.parse.urlparse(newurl).scheme != "https":
            raise YuanError("拒绝非加密重定向 / Refused an insecure redirect")
        return super().redirect_request(request, fp, code, message, headers, newurl)

class Network:
    def __init__(self, cancel=None):
        self.cancel = cancel
        self.latency = 1.0

    @property
    def timeout(self):
        return max(2.0, min(30.0, self.latency * 4))

    def request(self, url, headers=None):
        if urllib.parse.urlparse(url).scheme != "https":
            raise YuanError("仅允许加密网络连接 / Only HTTPS connections are permitted")
        check(self.cancel)
        request = urllib.request.Request(url, headers={"User-Agent": "Yuan-Audio/1.0 (local audio learning)", **(headers or {})})
        before = time.monotonic()
        done = threading.Event()
        abandoned = threading.Event()
        result_box = []
        def connect():
            result = None
            try:
                result = urllib.request.build_opener(HTTPSOnly()).open(request, timeout=self.timeout)
                if abandoned.is_set():
                    result.close()
                else:
                    result_box.append(result)
            except BaseException as exc:
                result_box.append(exc)
            finally:
                done.set()
                if abandoned.is_set() and result is not None:
                    result.close()
        threading.Thread(target=connect, daemon=True).start()
        try:
            while not done.wait(math.sqrt(tick())):
                check(self.cancel)
            check(self.cancel)
        except BaseException:
            abandoned.set()
            if result_box and not isinstance(result_box[0], BaseException):
                result_box[0].close()
            raise
        result = result_box[0]
        if isinstance(result, BaseException):
            raise result
        self.latency = (self.latency + time.monotonic() - before) / 2
        if urllib.parse.urlparse(result.geturl()).scheme != "https":
            result.close()
            raise YuanError("拒绝非加密重定向 / Refused an insecure redirect")
        return result

    def blocks(self, response):
        stopped = threading.Event()
        chunks = queue.Queue(maxsize=2)
        def send(value):
            while not stopped.is_set():
                try:
                    chunks.put(value, timeout=math.sqrt(tick()))
                    return
                except queue.Full:
                    pass
        def read():
            try:
                reader = getattr(response, "read1", response.read)
                while not stopped.is_set():
                    block = reader(1024 * 1024)
                    if not block:
                        break
                    send(block)
                send(None)
            except BaseException as exc:
                send(exc)
        thread = threading.Thread(target=read, daemon=True)
        thread.start()
        try:
            while True:
                check(self.cancel)
                try:
                    block = chunks.get(timeout=math.sqrt(tick()))
                except queue.Empty:
                    continue
                if block is None:
                    break
                if isinstance(block, BaseException):
                    raise block
                yield block
        finally:
            stopped.set()
            if thread.is_alive():
                try:
                    import socket
                    raw = getattr(getattr(response, "fp", None), "raw", None)
                    connection = getattr(raw, "_sock", None)
                    if connection:
                        connection.shutdown(socket.SHUT_RDWR)
                except OSError:
                    pass

    def json(self, url):
        payload = bytearray()
        with self.request(url) as response:
            for block in self.blocks(response):
                payload.extend(block)
                if len(payload) > 16 * 1024 * 1024:
                    raise YuanError("网络清单超过安全容量 / Network manifest exceeds safe capacity")
        check(self.cancel)
        return json.loads(payload)

    def download(self, url, target, expected_size=None, expected_hash=None, progress=None, max_bytes=None, algorithm=None):
        target = Path(target)
        part = target.with_name(target.name + ".partial")
        check(self.cancel)
        if target.is_symlink() or part.is_symlink():
            raise YuanError("拒绝使用链接指向的下载文件 / Refusing a linked download target")
        target.parent.mkdir(parents=True, exist_ok=True)
        algorithm = algorithm or "sha256"
        if algorithm not in ("sha1", "sha256"):
            raise YuanError("不支持的完整性算法 / Unsupported integrity algorithm")
        if expected_size is not None and (isinstance(expected_size, bool) or not isinstance(expected_size, int) or expected_size < 0):
            raise YuanError("无效的下载大小 / Invalid download size")
        if max_bytes is not None and (isinstance(max_bytes, bool) or not isinstance(max_bytes, int) or max_bytes < 0):
            raise YuanError("无效的下载资源预算 / Invalid download resource budget")
        if expected_hash:
            expected_hash = str(expected_hash).lower()
            if len(expected_hash) != hashlib.new(algorithm).digest_size * 2 or any(c not in "0123456789abcdef" for c in expected_hash):
                raise YuanError("无效的完整性摘要 / Invalid integrity digest")
        if max_bytes is not None and expected_size is not None and expected_size > max_bytes:
            raise YuanError("下载超过当前资源预算 / Download exceeds the current resource budget")
        if target.is_file():
            size = target.stat().st_size
            size_ok = (expected_size is None or size == expected_size) and (max_bytes is None or size <= max_bytes)
            hash_ok = not expected_hash or digest_file(target, self.cancel, algorithm) == expected_hash
            if size_ok and hash_ok:
                if progress:
                    progress(size, size)
                return target
        offset = part.stat().st_size if part.is_file() else 0
        if offset and (not expected_hash or max_bytes is not None and offset > max_bytes):
            part.unlink(missing_ok=True)
            offset = 0
        if expected_size is not None and offset >= expected_size:
            if offset == expected_size and part.is_file() and expected_hash and digest_file(part, self.cancel, algorithm) == expected_hash:
                check(self.cancel)
                os.replace(part, target)
                sync_dir(target.parent)
                if progress:
                    progress(offset, offset)
                return target
            part.unlink(missing_ok=True)
            offset = 0
        headers = {"Accept-Encoding": "identity"}
        if offset:
            headers["Range"] = f"bytes={offset}-"
        with self.request(url, headers) as response:
            status = getattr(response, "status", 200)
            if status not in (200, 206):
                raise YuanError(f"下载状态异常 / Unexpected download status: {status}")
            if response.headers.get("Content-Encoding", "identity").strip().lower() not in ("", "identity"):
                raise YuanError("下载编码与原始文件不匹配 / Download encoding differs from the original file")
            length = response.headers.get("Content-Length")
            if length is not None and not re.fullmatch(r"[0-9]+", length.strip()):
                raise YuanError("下载长度无效 / Invalid download content length")
            length = int(length) if length is not None else None
            response_end = None
            if status == 206:
                match = re.fullmatch(r"bytes ([0-9]+)-([0-9]+)/([0-9]+|\*)", response.headers.get("Content-Range", "").strip())
                if match is None:
                    raise YuanError("下载续传范围无效 / Invalid download content range")
                first, last = int(match[1]), int(match[2])
                complete = int(match[3]) if match[3] != "*" else None
                if first != offset or last < first or complete is not None and last >= complete:
                    raise YuanError("下载续传偏移不匹配 / Download resume offset mismatch")
                if length is not None and length != last - first + 1:
                    raise YuanError("下载范围与长度不匹配 / Download range and length mismatch")
                response_end = last + 1
                total = complete if complete is not None else expected_size
                if total is None:
                    raise YuanError("无法确认下载完整长度 / Cannot establish the complete download length")
            else:
                offset = 0
                total = length if length is not None else expected_size
            if expected_size is not None and total is not None and total != expected_size:
                raise YuanError("下载大小与可信清单不匹配 / Download size differs from the trusted manifest")
            if max_bytes is not None and total is not None and total > max_bytes:
                raise YuanError("下载超过当前资源预算 / Download exceeds the current resource budget")
            written = offset
            with part.open("ab" if offset else "wb") as stream:
                for block in self.blocks(response):
                    check(self.cancel)
                    written += len(block)
                    limits = (expected_size, max_bytes, total, response_end)
                    if any(bound is not None and written > bound for bound in limits):
                        raise YuanError("下载超过已声明大小 / Download exceeds its declared size")
                    if shutil.disk_usage(target.parent).free < len(block):
                        raise YuanError("所选目录空间不足 / The selected folder is out of space")
                    stream.write(block)
                    if progress:
                        progress(written, total)
                stream.flush()
                os.fsync(stream.fileno())
        check(self.cancel)
        declared = expected_size if expected_size is not None else total
        if (declared is not None and written != declared) or (response_end is not None and written != response_end):
            raise YuanError("下载尚未完整 / Download is incomplete")
        if expected_hash and digest_file(part, self.cancel, algorithm) != expected_hash:
            part.unlink(missing_ok=True)
            raise YuanError("文件完整性校验失败 / File integrity validation failed")
        check(self.cancel)
        os.replace(part, target)
        sync_dir(target.parent)
        return target



class AudioStore:
    def __init__(self, state, recover=True):
        self.root = safe_path(state, "memory")
        self.root.mkdir(parents=True, exist_ok=True)
        self.audio = safe_path(self.root, "audio")
        self.audio.mkdir(exist_ok=True)
        self.db = sqlite3.connect(str(database_path(self.root, "memory.sqlite3")), timeout=math.sqrt(os.cpu_count() or 1))
        self.db.row_factory = sqlite3.Row
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.execute("PRAGMA foreign_keys=ON")
        self.db.executescript("""
        CREATE TABLE IF NOT EXISTS groups(id TEXT PRIMARY KEY, split TEXT NOT NULL CHECK(split IN ('train','validation','guard')), origin TEXT NOT NULL, created REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS sessions(id TEXT PRIMARY KEY, prompt TEXT NOT NULL, language TEXT NOT NULL, started REAL NOT NULL, ended REAL);
        CREATE TABLE IF NOT EXISTS samples(id TEXT PRIMARY KEY, group_id TEXT NOT NULL REFERENCES groups(id), role TEXT NOT NULL, audio TEXT NOT NULL, seconds REAL NOT NULL, rate INTEGER NOT NULL, count INTEGER NOT NULL, cursor INTEGER NOT NULL DEFAULT 0, visits INTEGER NOT NULL DEFAULT 0, created REAL NOT NULL, digest TEXT NOT NULL, generated INTEGER NOT NULL CHECK(generated IN (0,1)), learnable INTEGER NOT NULL CHECK(learnable IN (0,1)), metadata TEXT NOT NULL DEFAULT '{}');
        CREATE INDEX IF NOT EXISTS sample_group ON samples(group_id, created);
        CREATE INDEX IF NOT EXISTS sample_digest ON samples(digest);
        CREATE INDEX IF NOT EXISTS sample_learning ON samples(learnable, visits, created);
        CREATE TABLE IF NOT EXISTS sources(id TEXT PRIMARY KEY, url TEXT NOT NULL, path TEXT, metadata TEXT NOT NULL, offset INTEGER NOT NULL DEFAULT 0, finished INTEGER NOT NULL DEFAULT 0, created REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
        """)
        if recover:
            self.db.execute("UPDATE sessions SET ended=? WHERE ended IS NULL", (time.time(),))
            self.db.commit()
            for path in self.audio.glob("*.partial"):
                path.unlink(missing_ok=True)
            self.repair()

    def repair(self):
        for row in self.db.execute("SELECT id,audio FROM samples").fetchall():
            if not safe_path(self.root, row["audio"]).is_file():
                self.db.execute("UPDATE samples SET learnable=0 WHERE id=?", (row["id"],))
        self.db.commit()
        tracked = {row[0] for row in self.db.execute("SELECT audio FROM samples")}
        for path in self.audio.glob("*.flac"):
            if path.relative_to(self.root).as_posix() not in tracked and len(path.stem) == hashlib.sha256().digest_size * 2:
                path.unlink(missing_ok=True)

    def setting(self, key, default=None):
        row = self.db.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        if not row:
            return default
        try:
            return json.loads(row[0])
        except (ValueError, TypeError):
            return default

    def set_setting(self, key, value):
        encoded = json.dumps(value, ensure_ascii=False, allow_nan=False)
        row = self.db.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        if row and row[0] == encoded:
            return
        self.db.execute("INSERT OR REPLACE INTO settings VALUES(?,?)", (key, encoded))
        self.db.commit()

    def group(self, group_id, origin, forced=None):
        row = self.db.execute("SELECT split FROM groups WHERE id=?", (group_id,)).fetchone()
        if row:
            return row[0]
        counts = dict(self.db.execute("SELECT split,count(*) FROM groups WHERE id IN (SELECT group_id FROM samples WHERE learnable=1) GROUP BY split"))
        total = sum(counts.values())
        empty = next((name for name in ("train", "validation", "guard") if not counts.get(name)), None)
        if forced in ("train", "validation", "guard"):
            split = forced
        elif origin == "local":
            split = "train"
        elif empty:
            split = empty
        else:
            target = math.isqrt(total + 1)
            split = min(("validation", "guard"), key=lambda name: counts.get(name, 0))
            if counts.get(split, 0) >= target:
                split = "train"
        self.db.execute("INSERT INTO groups VALUES(?,?,?,?)", (group_id, split, origin, time.time()))
        self.db.commit()
        return split

    def session(self, session_id, prompt, language):
        self.db.execute("INSERT INTO sessions VALUES(?,?,?,?,NULL)", (session_id, prompt, language, time.time()))
        self.db.commit()

    def end_session(self, session_id):
        self.db.execute("UPDATE sessions SET ended=? WHERE id=? AND ended IS NULL", (time.time(), session_id))
        self.db.commit()

    def add(self, group_id, role, waveform, rate, origin, cancel=None, generated=False, eligible=True, created=None, metadata=None):
        import numpy as np
        import soundfile as sf
        waveform = np.asarray(waveform, dtype=np.float32).reshape(-1)
        if not waveform.size or not np.isfinite(waveform).all() or not isinstance(rate, int) or rate <= 0:
            raise YuanError("音频样本无效 / Invalid audio sample")
        if np.max(np.abs(waveform)) > 1:
            raise YuanError("音频超出可保存范围 / Audio is outside the supported range")
        generated = bool(generated or (origin == "local" and role == "assistant"))
        created = time.time() if created is None else float(created)
        if not math.isfinite(created):
            raise YuanError("音频时间无效 / Invalid audio timestamp")
        encoded_metadata = json.dumps(metadata or {}, ensure_ascii=False, allow_nan=False, separators=(",", ":"))
        canonical = np.floor(waveform.astype(np.float64) * (1 << 23)).clip(-(1 << 23), (1 << 23) - 1).astype("<i4")
        checksum = hashlib.sha256(canonical.tobytes() + str(rate).encode("ascii")).hexdigest()
        existing = self.db.execute("SELECT id FROM samples WHERE digest=? AND group_id=? AND role=?", (checksum, group_id, role)).fetchone()
        if existing and origin == "public":
            return existing[0]
        duplicate = self.db.execute("SELECT 1 FROM samples WHERE digest=? AND learnable=1", (checksum,)).fetchone()
        check(cancel)
        self.group(group_id, origin)
        sample_id = uuid.uuid4().hex
        target = safe_path(self.audio, checksum + ".flac")
        temporary = self.audio / (checksum + "-" + uuid.uuid4().hex + ".partial")
        new_file = not target.is_file()
        if shutil.disk_usage(self.root).free < waveform.nbytes * 2 + self.db_size():
            raise YuanError("所选目录空间不足 / The selected folder is out of space")
        try:
            if new_file:
                sf.write(str(temporary), waveform, rate, format="FLAC", subtype="PCM_24")
                with temporary.open("rb") as stream:
                    os.fsync(stream.fileno())
                check(cancel)
                os.replace(temporary, target)
                sync_dir(target.parent)
            check(cancel)
            self.db.execute("INSERT INTO samples(id,group_id,role,audio,seconds,rate,count,created,digest,generated,learnable,metadata) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                            (sample_id, group_id, role, target.relative_to(self.root).as_posix(), len(waveform) / rate, rate, len(waveform), created, checksum, int(generated), int(bool(eligible) and not generated and not duplicate), encoded_metadata))
            self.db.commit()
        except BaseException:
            self.db.rollback()
            temporary.unlink(missing_ok=True)
            if new_file and not self.db.execute("SELECT 1 FROM samples WHERE digest=?", (checksum,)).fetchone():
                target.unlink(missing_ok=True)
            raise
        return sample_id

    def db_size(self):
        return sum(path.stat().st_size for path in self.root.glob("memory.sqlite3*") if path.is_file())

    def next_sample(self, split):
        return self.db.execute("SELECT samples.*,groups.split,groups.origin FROM samples JOIN groups ON groups.id=group_id WHERE split=? AND learnable=1 AND generated=0 AND count>1 ORDER BY visits,samples.created LIMIT 1", (split,)).fetchone()

    def held_out(self, split):
        return self.db.execute("SELECT s.*,g.split,g.origin FROM samples s JOIN groups g ON g.id=s.group_id WHERE g.split=? AND s.learnable=1 AND s.generated=0 AND s.count>1 AND s.id=(SELECT t.id FROM samples t WHERE t.group_id=s.group_id AND t.learnable=1 AND t.generated=0 AND t.count>1 ORDER BY t.created,t.id LIMIT 1) ORDER BY g.created,g.id", (split,)).fetchall()

    def advance(self, row, cursor):
        wrapped = cursor >= row["count"]
        self.db.execute("UPDATE samples SET cursor=?,visits=visits+? WHERE id=?", (0 if wrapped else max(0, cursor), int(wrapped), row["id"]))
        self.db.commit()

    def stats(self):
        rows = self.db.execute("SELECT origin,count(*) AS n,coalesce(sum(seconds),0) AS seconds,sum(learnable) AS learnable,sum(generated) AS generated,sum(1-generated-learnable) AS excluded FROM samples JOIN groups ON groups.id=group_id GROUP BY origin").fetchall()
        return {row["origin"]: {"count": row["n"], "seconds": row["seconds"], "learnable": row["learnable"], "generated": row["generated"], "excluded": row["excluded"]} for row in rows}

    def close(self):
        try:
            self.db.execute("PRAGMA wal_checkpoint(PASSIVE)")
        finally:
            self.db.close()

class NativeAudio:
    def __init__(self, state, cancel, emit):
        import numpy as np
        import psutil
        import torch
        self.np, self.torch, self.emit, self.state = np, torch, emit, Path(state)
        self.cancel = cancel
        self.input_budget = None
        self.steps = 0
        self.accepted = 0
        self.capacity_scale = 1.0
        self.active_digest = None
        self.device = self._device()
        self.dtype = torch.float32
        self.rate, self.hop, self.width, self.layers, self.chunk_seconds, self.capacity_seconds = self._configuration(psutil)
        try:
            available_cpus = len(psutil.Process().cpu_affinity())
        except (AttributeError, OSError, NotImplementedError, psutil.Error):
            available_cpus = os.cpu_count() or 1
        torch.set_num_threads(max(1, math.isqrt(available_cpus)))
        self.output_rate = self.rate
        try:
            self.network = self._build().to(self.device, dtype=self.dtype)
        except (RuntimeError, MemoryError) as exc:
            if self.device.type == "cpu":
                raise
            self.emit("notice", key="device_fallback", reason=concise_error(exc))
            self.device = torch.device("cpu")
            self.network = self._build().to(self.device, dtype=self.dtype)
        self.restore()
        self.network.eval().requires_grad_(False)
        parameters = sum(value.numel() for value in self.network.parameters())
        self.model_bytes = parameters * torch.finfo(self.dtype).bits // 8
        self.emit("model", name="Yuan Native Audio", device=str(self.device), dtype=str(self.dtype).replace("torch.", ""),
                  input_rate=self.rate, output_rate=self.output_rate, architecture=f"{self.width}d · {self.layers} encoder/decoder · {self.hop} samples/frame",
                  identity=self.identity()[:12], mode="ordered prompt + audio → autoregressive waveform", size=human_bytes(self.model_bytes), parameters=parameters,
                  accepted=self.accepted, steps=self.steps, conversation_verified=False, capability="experimental" if self.accepted else "cold_start")

    def _device(self):
        torch = self.torch
        if torch.cuda.is_available():
            return torch.device("cuda")
        if hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
            return torch.device("mps")
        return torch.device("cpu")

    def _configuration(self, psutil):
        path = safe_path(self.state, "learning/model.json")
        saved = read_json(path)
        total_gib = max(1.0, psutil.virtual_memory().available / (1024 ** 3))
        cpu = max(1, os.cpu_count() or 1)
        rates = []
        try:
            import sounddevice as sd
            devices = sd.query_devices()
            defaults = sd.default.device
            for position, direction in enumerate(("input", "output")):
                index = defaults[position]
                if index is not None and 0 <= index < len(devices) and devices[index]["max_" + direction + "_channels"] > 0:
                    value = int(round(float(devices[index]["default_samplerate"])))
                    if value > 0:
                        rates.append(value)
        except Exception:
            pass
        resource_target = max(8000.0, min(48000.0, 4096.0 * math.sqrt(cpu * math.sqrt(total_gib))))
        resource_rate = max(8000, min(48000, int(2 ** round(math.log2(resource_target)))))
        generated = {
            "rate": min(resource_rate, min(rates)) if rates else resource_rate,
            "width": int(2 ** round(math.log2(max(32, min(128, 16 * math.sqrt(cpu * math.sqrt(total_gib))))))),
            "layers": max(1, min(3, int(round(math.log2(cpu + 1) / 2)))),
        }
        generated["hop"] = int(2 ** round(math.log2(math.sqrt(generated["rate"]))))
        generated["chunk_seconds"] = max(2.0, min(8.0, math.sqrt(cpu)))
        generated["capacity_seconds"] = max(generated["chunk_seconds"] * 3, min(generated["chunk_seconds"] * 12, generated["chunk_seconds"] * 2 * math.sqrt(total_gib)))
        if isinstance(saved, dict):
            try:
                rate = int(saved["rate"])
                hop = int(saved["hop"])
                width = int(saved["width"])
                layers = int(saved["layers"])
                chunk = float(saved["chunk_seconds"])
                capacity = float(saved["capacity_seconds"])
                if 8000 <= rate <= 96000 and hop > 0 and hop <= rate and 16 <= width <= 512 and 1 <= layers <= 8 and math.isfinite(chunk) and math.isfinite(capacity) and chunk > 0 and capacity >= chunk:
                    return rate, hop, width, layers, chunk, capacity
            except (KeyError, TypeError, ValueError, OverflowError):
                pass
        path.parent.mkdir(parents=True, exist_ok=True)
        atomic_json(path, generated, self.cancel)
        return generated["rate"], generated["hop"], generated["width"], generated["layers"], generated["chunk_seconds"], generated["capacity_seconds"]

    def _build(self):
        torch, width, hop, layers = self.torch, self.width, self.hop, self.layers
        class Net(torch.nn.Module):
            def __init__(self):
                super().__init__()
                self.prompt = torch.nn.Embedding(256, width)
                self.prompt_recurrent = torch.nn.GRU(width, width, batch_first=True)
                self.prompt_mix = torch.nn.Sequential(torch.nn.Linear(width, width), torch.nn.Tanh())
                self.roles = torch.nn.Embedding(2, width)
                self.input = torch.nn.Linear(hop, width)
                self.norm = torch.nn.LayerNorm(width)
                self.encoder = torch.nn.GRU(width, width, num_layers=layers, batch_first=True)
                self.decoder_input = torch.nn.Linear(hop, width)
                self.decoder = torch.nn.GRU(width, width, num_layers=layers, batch_first=True)
                self.output = torch.nn.Linear(width, hop)
                self.ending = torch.nn.Linear(width, 1)
                self.begin = torch.nn.Parameter(torch.zeros(1, 1, hop))
                torch.nn.init.xavier_uniform_(self.output.weight, gain=1 / math.sqrt(width))
                torch.nn.init.zeros_(self.output.bias)
                torch.nn.init.zeros_(self.ending.bias)
            def condition(self, ids, hidden=None):
                _, hidden = self.prompt_recurrent(self.prompt(ids), hidden)
                return hidden
            def initial(self, prompt_hidden):
                return self.prompt_mix(prompt_hidden).expand(layers, -1, -1).contiguous()
            def encode(self, frames, hidden, role):
                values = self.norm(torch.tanh(self.input(frames)) + self.roles.weight[role].reshape(1, 1, -1))
                _, hidden = self.encoder(values, hidden)
                return hidden
            def decode(self, previous, hidden):
                values, hidden = self.decoder(torch.tanh(self.decoder_input(previous)), hidden)
                return torch.tanh(self.output(values)), self.ending(values).squeeze(-1), hidden
        return Net()

    @contextmanager
    def interruptible(self, cancel):
        previous = self.cancel
        self.cancel = cancel
        try:
            check(cancel)
            yield
        finally:
            self.cancel = previous

    def capacity(self):
        import psutil
        sample_bytes = self.np.dtype(self.np.float32).itemsize
        memory_bound = psutil.virtual_memory().available // max(sample_bytes * 24, self.width * sample_bytes)
        configured = int(self.rate * self.capacity_seconds * self.capacity_scale)
        return max(self.hop * 2, min(configured, int(memory_bound)))

    def window(self):
        return max(self.hop * 2, min(self.capacity() // 4, int(self.rate * self.chunk_seconds / 2)))

    def required_training_memory(self):
        frames = math.ceil(self.window() / self.hop)
        return self.model_bytes * 16 + frames * self.width * self.layers * self.np.dtype(self.np.float32).itemsize * 64

    def normalize(self, waveform, rate):
        import soxr
        np = self.np
        waveform = np.asarray(waveform, dtype=np.float32)
        if waveform.ndim == 2:
            waveform = waveform.mean(axis=-1)
        if waveform.ndim != 1 or not waveform.size or rate <= 0 or not np.isfinite(waveform).all():
            raise YuanError("输入音频无效 / Invalid input audio")
        if int(rate) != self.rate:
            waveform = soxr.resample(waveform, int(rate), self.rate).astype(np.float32)
        waveform = waveform - waveform.mean(dtype=np.float64)
        peak = float(np.max(np.abs(waveform)))
        if peak > 1:
            waveform = waveform / peak
        if not waveform.size or not np.isfinite(waveform).all():
            raise YuanError("处理后的音频含无效数值 / Processed audio contains invalid values")
        return np.ascontiguousarray(waveform, dtype=np.float32)

    def _prompt_ids(self, prompt):
        import psutil
        data = str(prompt).encode("utf-8") or b"\0"
        budget = max(self.width, psutil.virtual_memory().available // max(1, self.width * self.torch.tensor([], dtype=self.dtype).element_size() * 16))
        if len(data) > budget:
            raise YuanError("提示词超过当前内存预算 / Instructions exceed the current memory budget")
        return self.torch.tensor(list(data), dtype=self.torch.long, device=self.device).reshape(1, -1)

    def _frames(self, waveform):
        torch = self.torch
        np = self.np
        values = np.asarray(waveform, dtype=np.float32).reshape(-1)
        missing = (-len(values)) % self.hop
        if missing:
            values = np.pad(values, (0, missing))
        tensor = torch.from_numpy(values.copy()).to(self.device, dtype=self.dtype).reshape(1, -1, self.hop)
        return tensor, len(waveform)

    def _encode(self, network, prompt, waveform, context=(), cancel=None):
        ids = self._prompt_ids(prompt)
        hidden = None
        step = max(1, self.width)
        for start in range(0, ids.shape[1], step):
            check(cancel)
            hidden = network.condition(ids[:, start:start + step], hidden)
        hidden = network.initial(hidden)
        for role, audio in (*context, ("user", waveform)):
            check(cancel)
            if not len(audio):
                continue
            frames, _ = self._frames(audio)
            for start in range(0, frames.shape[1], step):
                check(cancel)
                hidden = network.encode(frames[:, start:start + step], hidden, int(role == "assistant"))
        return hidden

    def reply_samples(self, incoming, history=()):
        np = self.np
        incoming_seconds = max(self.hop / self.rate, len(incoming) / self.rate)
        assistant_seconds = [len(values) / self.rate for role, values in history if role == "assistant" and len(values)]
        if assistant_seconds:
            recent = assistant_seconds[-max(1, math.isqrt(len(assistant_seconds))):]
            reference = float(np.median(np.asarray(recent, dtype=np.float64)))
        else:
            reference = self.chunk_seconds
        target = math.sqrt(incoming_seconds * max(self.hop / self.rate, reference))
        target = max(self.hop / self.rate, min(target, self.capacity() / self.rate / 2))
        return max(self.hop, min(self.capacity(), int(math.ceil(target * self.rate / self.hop)) * self.hop))

    def _decode(self, network, hidden, count, cancel=None, stop=True, phase=False):
        torch = self.torch
        previous = network.begin
        pieces = []
        total = max(1, math.ceil(count / self.hop))
        last = 0.0
        stopped = False
        for frame in range(total):
            check(cancel)
            predicted, ending, hidden = network.decode(previous, hidden)
            if not torch.isfinite(predicted).all() or not torch.isfinite(ending).all():
                raise YuanError("模型输出含无效数值 / Model output contains invalid values")
            pieces.append(predicted)
            previous = predicted
            now = time.monotonic()
            if phase and (now - last >= math.sqrt(self.hop / self.rate) or frame + 1 == total):
                self.emit("phase", key="generating", current=frame + 1, total=total, unit="frames")
                last = now
            if stop and ending.item() > 0:
                stopped = True
                break
        if phase and stop and not stopped:
            self.emit("notice", key="limited", component="generation")
        return torch.cat(pieces, dim=1).reshape(1, -1)[:, :count]

    def respond_audio(self, prompt, history, waveform, cancel, max_samples=None):
        np, torch = self.np, self.torch
        incoming = np.asarray(waveform, dtype=np.float32).reshape(-1)
        if not incoming.size or not np.isfinite(incoming).all():
            raise YuanError("模型输入音频无效 / Invalid model audio input")
        incoming = incoming[-self.capacity():]
        history_budget = max(0, self.capacity() - len(incoming))
        prior = []
        used = 0
        for role, values in reversed(history):
            piece = np.asarray(values, dtype=np.float32).reshape(-1)
            if not piece.size or not np.isfinite(piece).all():
                continue
            take = min(len(piece), history_budget - used)
            if take <= 0:
                break
            prior.append((role, piece[-take:]))
            used += take
        network = self.network
        count = max(self.hop, min(int(max_samples) if max_samples else self.reply_samples(incoming, tuple(reversed(prior))), self.capacity()))
        self.emit("phase", key="prefill", current=used + len(incoming), total=self.capacity(), unit="samples", reply_samples=count, reply_seconds=count / self.rate)
        network.eval()
        with self.interruptible(cancel), torch.inference_mode():
            hidden = self._encode(network, prompt, incoming, tuple(reversed(prior)), cancel)
            result = self._decode(network, hidden, count, cancel, phase=True)
            values = result.reshape(-1).detach().float().cpu().numpy()
        check(cancel)
        if not values.size or not np.isfinite(values).all():
            raise YuanError("模型未产生有效音频 / Model produced no valid audio")
        rms = float(np.sqrt(np.mean(values.astype(np.float64) ** 2)))
        reference = float(np.sqrt(np.mean(incoming.astype(np.float64) ** 2)))
        if rms <= np.finfo(np.float32).eps or reference <= np.finfo(np.float32).eps:
            raise YuanError("模型输出或输入为静音 / Model output or input is silent")
        values = values * min(1.0, reference / rms)
        return np.ascontiguousarray(values, dtype=np.float32)

    def _acoustic_loss(self, prediction, target):
        torch = self.torch
        waveform = torch.nn.functional.smooth_l1_loss(prediction, target)
        motion = torch.nn.functional.smooth_l1_loss(prediction[:, 1:] - prediction[:, :-1], target[:, 1:] - target[:, :-1]) if target.shape[1] > 1 else waveform * 0
        spectra = []
        maximum = min(target.shape[1], self.hop * max(2, self.layers + 1))
        size = self.hop
        while size <= maximum:
            window = torch.hann_window(size, device=prediction.device, dtype=prediction.dtype)
            left = prediction.unfold(-1, size, max(1, size // 2)) * window
            right = target.unfold(-1, size, max(1, size // 2)) * window
            left = torch.log1p(torch.abs(torch.fft.rfft(left, dim=-1)))
            right = torch.log1p(torch.abs(torch.fft.rfft(right, dim=-1)))
            spectra.append(torch.nn.functional.smooth_l1_loss(left, right))
            size *= 2
        spectrum = sum(spectra) / len(spectra) if spectra else waveform * 0
        return waveform + motion + spectrum

    def loss(self, network, prompt, source, target, ended=False, context=(), rollout=False):
        torch = self.torch
        check(self.cancel)
        n = min(len(target), self.window())
        if n < self.hop or len(source) < self.hop:
            raise YuanError("音频样本过短，无法学习 / Audio sample is too short to learn from")
        hidden = self._encode(network, prompt, source, context, self.cancel)
        target_frames, _ = self._frames(target[:n])
        previous = torch.cat((network.begin, target_frames[:, :-1]), dim=1)
        predictions = []
        endings = []
        step = max(1, self.width)
        current_hidden = hidden
        for start in range(0, previous.shape[1], step):
            check(self.cancel)
            predicted, ending, current_hidden = network.decode(previous[:, start:start + step], current_hidden)
            predictions.append(predicted)
            endings.append(ending)
        prediction = torch.cat(predictions, dim=1).reshape(1, -1)[:, :n]
        target_tensor = target_frames.reshape(1, -1)[:, :n]
        loss = self._acoustic_loss(prediction, target_tensor)
        end_logits = torch.cat(endings, dim=1)
        end_target = torch.zeros_like(end_logits)
        if ended and n == len(target):
            end_target[:, -1] = 1
        end_loss = torch.nn.functional.binary_cross_entropy_with_logits(end_logits, end_target)
        loss = loss + end_loss / math.sqrt(max(1, n / self.hop))
        if rollout:
            free = self._decode(network, hidden, n, self.cancel, stop=False)
            loss = loss + self._acoustic_loss(free, target_tensor)
        return loss

    def clone(self):
        return copy.deepcopy(self.network).to(self.device, dtype=self.dtype)

    def identity(self):
        payload = ["yuan-owned-autoregressive-waveform-v2", self.rate, self.hop, self.width, self.layers]
        return hashlib.sha256(json.dumps(payload, separators=(",", ":")).encode()).hexdigest()

    def restore(self):
        directory = safe_path(self.state, "learning")
        directory.mkdir(parents=True, exist_ok=True)
        manifest = read_json(directory / "active.json")
        if isinstance(manifest, dict) and manifest.get("identity") == self.identity():
            try:
                path = safe_path(directory, manifest["file"])
                if digest_file(path, self.cancel) != manifest["sha256"]:
                    raise YuanError("模型完整性校验失败 / Model integrity validation failed")
                weights = self.torch.load(str(path), map_location="cpu", weights_only=True)
                if not isinstance(weights, dict) or not weights or not all(isinstance(value, self.torch.Tensor) and self.torch.isfinite(value).all() for value in weights.values()):
                    raise YuanError("模型权重无效 / Invalid model weights")
                self.network.load_state_dict(weights, strict=True)
                self.network.to(self.device, dtype=self.dtype).eval()
                self.steps = max(0, int(manifest.get("steps", 0)))
                self.accepted = max(0, int(manifest.get("accepted", 0)))
                self.active_digest = manifest["sha256"]
                return
            except Cancelled:
                raise
            except Exception as exc:
                self.emit("notice", key="checkpoint_failure", reason=concise_error(exc))
                self.network = self._build().to(self.device, dtype=self.dtype)
        self._persist(self.network, {}, self.cancel, increment=False)

    def _persist(self, network, metrics, cancel, increment):
        directory = safe_path(self.state, "learning")
        directory.mkdir(parents=True, exist_ok=True)
        name = "model-" + uuid.uuid4().hex + ".pt"
        target = directory / name
        temporary = target.with_suffix(".partial")
        check(cancel)
        committed = False
        try:
            self.torch.save({key: value.detach().cpu().contiguous() for key, value in network.state_dict().items()}, str(temporary))
            with temporary.open("rb") as stream:
                os.fsync(stream.fileno())
            check(cancel)
            os.replace(temporary, target)
            accepted = self.accepted + int(bool(increment))
            checksum = digest_file(target, cancel)
            manifest = {"identity": self.identity(), "file": name, "sha256": checksum, "steps": self.steps,
                        "accepted": accepted, "metrics": metrics, "conversation_verified": False, "created": time.time()}
            atomic_json(directory / "active.json", manifest, cancel)
            committed = True
            self.accepted = accepted
            self.active_digest = checksum
        finally:
            temporary.unlink(missing_ok=True)
            if not committed:
                target.unlink(missing_ok=True)
        for old in directory.glob("model-*.pt"):
            if old != target:
                try:
                    old.unlink(missing_ok=True)
                except OSError as exc:
                    self.emit("notice", reason=concise_error(exc), component="checkpoint_cleanup")

    def promote(self, candidate, metrics, cancel):
        active = copy.deepcopy(candidate).eval().requires_grad_(False)
        self._persist(active, metrics, cancel, increment=True)
        self.network = active

class AudioLearner:
    def __init__(self, model, store, emit):
        self.model, self.store, self.emit = model, store, emit
        self.steps = model.steps
        self.candidate = None
        self.optimizer = None
        self.training_loss = None
        self.dirty = False
        self.checkpoint_base = model.active_digest

    def _prepare(self, cancel):
        if self.candidate is not None:
            return
        torch = self.model.torch
        check(cancel)
        self.candidate = self.model.clone().train().requires_grad_(True)
        parameters = sum(value.numel() for value in self.candidate.parameters())
        self.optimizer = torch.optim.AdamW(self.candidate.parameters(), lr=1 / math.sqrt(parameters), weight_decay=1 / parameters)
        directory = safe_path(self.model.state, "learning")
        manifest = read_json(directory / "candidate.json")
        if not isinstance(manifest, dict) or manifest.get("identity") != self.model.identity():
            return
        try:
            target = safe_path(directory, manifest["file"])
            if manifest.get("base") != self.model.active_digest or digest_file(target, cancel) != manifest.get("sha256"):
                raise YuanError("候选存档基线或摘要不匹配 / Candidate checkpoint baseline or digest mismatch")
            state = torch.load(str(target), map_location="cpu", weights_only=True)
            if not all(isinstance(value, torch.Tensor) and torch.isfinite(value).all() for value in state["network"].values()):
                raise YuanError("候选权重无效 / Invalid candidate weights")
            self.candidate.load_state_dict(state["network"], strict=True)
            self.optimizer.load_state_dict(state["optimizer"])
            for values in self.optimizer.state.values():
                for value in values.values():
                    if isinstance(value, torch.Tensor) and not torch.isfinite(value).all():
                        raise YuanError("优化器状态无效 / Invalid optimizer state")
            steps = int(state["steps"])
            training_loss = state.get("training_loss")
            if steps < 0 or training_loss is not None and not math.isfinite(float(training_loss)):
                raise YuanError("候选训练指标无效 / Invalid candidate training measurements")
            self.steps = max(self.model.steps, steps)
            self.model.steps = self.steps
            self.training_loss = float(training_loss) if training_loss is not None else None
            self.dirty = False
            self.checkpoint_base = self.model.active_digest
            self.emit("learning", key="candidate_recovered", steps=self.steps, accepted=self.model.accepted)
        except Cancelled:
            self.candidate = self.optimizer = None
            raise
        except Exception as exc:
            self.emit("notice", key="checkpoint_failure", component="candidate", reason=concise_error(exc))
            self.candidate = self.model.clone().train().requires_grad_(True)
            self.optimizer = torch.optim.AdamW(self.candidate.parameters(), lr=1 / math.sqrt(parameters), weight_decay=1 / parameters)
            self.steps = self.model.steps
            self.training_loss = None

    def checkpoint(self, cancel):
        if self.candidate is None or not self.dirty and self.checkpoint_base == self.model.active_digest:
            return
        self.emit("phase", key="checkpointing", steps=self.steps)
        directory = safe_path(self.model.state, "learning")
        name = "candidate-" + uuid.uuid4().hex + ".pt"
        target = directory / name
        temporary = target.with_suffix(".partial")
        committed = False
        try:
            check(cancel)
            payload = {"network": {key: value.detach().cpu().contiguous() for key, value in self.candidate.state_dict().items()},
                       "optimizer": self.optimizer.state_dict(), "steps": self.steps, "training_loss": self.training_loss}
            self.model.torch.save(payload, str(temporary))
            with temporary.open("rb") as stream:
                os.fsync(stream.fileno())
            check(cancel)
            os.replace(temporary, target)
            atomic_json(directory / "candidate.json", {"identity": self.model.identity(), "base": self.model.active_digest,
                        "file": name, "sha256": digest_file(target, cancel), "steps": self.steps, "created": time.time()}, cancel)
            committed = True
            self.dirty = False
            self.checkpoint_base = self.model.active_digest
            self.emit("checkpoint_saved", steps=self.steps, base=self.checkpoint_base)
        finally:
            temporary.unlink(missing_ok=True)
            if not committed:
                target.unlink(missing_ok=True)
        for old in directory.glob("candidate-*.pt"):
            if old != target:
                try:
                    old.unlink(missing_ok=True)
                except OSError as exc:
                    self.emit("notice", reason=concise_error(exc), component="candidate_cleanup")

    def _prompt(self, row):
        session = self.store.db.execute("SELECT prompt FROM sessions WHERE id=?", (row["group_id"],)).fetchone()
        if session and isinstance(session["prompt"], str) and session["prompt"].strip():
            return session["prompt"]
        source_id = row["group_id"].removeprefix("public-")
        source = self.store.db.execute("SELECT metadata FROM sources WHERE id=?", (source_id,)).fetchone()
        language = self.store.setting("language", "中文")
        if source:
            metadata = json.loads(source["metadata"])
            language = "English" if metadata.get("language") == "English" else "中文"
            title = re.sub(r"<[^>]*>|[_]+", " ", str(metadata.get("title", ""))).strip()
            title = re.sub(r"^file:\s*", "", title, flags=re.IGNORECASE)
            title = re.sub(r"\.(?:flac|ogg|oga|wav|mp3|opus)\s*$", "", title, flags=re.IGNORECASE)
            title = re.sub(r"\s+", " ", title)
            if title:
                return ("自然理解并回应与这段公开语音相关的内容：" if language == "中文" else "Understand and respond naturally to the content related to this public speech: ") + title
        return tr("default_prompt", language)

    def _audio(self, row, cancel, start, count):
        import soundfile as sf
        check(cancel)
        with sf.SoundFile(str(safe_path(self.store.root, row["audio"]))) as stream:
            if stream.samplerate != self.model.rate or stream.channels != 1 or stream.frames != row["count"]:
                raise YuanError("历史音频格式或长度不匹配 / Historical audio format or length mismatch")
            stream.seek(max(0, min(start, stream.frames)))
            values = stream.read(max(0, count), dtype="float32", always_2d=False)
        if not values.size or not self.model.np.isfinite(values).all():
            raise YuanError("历史音频无效 / Historical audio is invalid")
        check(cancel)
        return values

    def features(self, row, cancel, held_out=False):
        hop = self.model.hop
        total = row["count"]
        if row["generated"] or not row["learnable"] or total < hop * 2:
            raise YuanError("样本不能作为真实音频目标 / Sample cannot be used as a real audio target")
        window = self.model.window()
        if held_out:
            slots = max(1, (total - hop * 2) // hop + 1)
            cursor = (int(row["digest"][:16], 16) % slots) * hop
        else:
            cursor = max(0, min(int(row["cursor"]), total - hop * 2))
        start = max(hop, cursor)
        start -= start % hop
        end = min(total, start + window)
        source_start = max(0, start - window)
        audio = self._audio(row, cancel, source_start, end - source_start)
        cut = start - source_start
        source, target = audio[:cut], audio[cut:]
        if len(target) < hop:
            raise YuanError("音频目标过短 / Audio target is too short")
        context = []
        if row["origin"] == "local":
            budget = max(0, self.model.capacity() // 2 - len(source))
            used = 0
            previous_rows = self.store.db.execute("SELECT * FROM samples WHERE group_id=? AND created<? ORDER BY created DESC", (row["group_id"], row["created"]))
            for previous in previous_rows:
                check(cancel)
                remaining = budget - used
                if remaining < hop:
                    break
                take = min(window, previous["count"], remaining)
                if take < hop:
                    continue
                try:
                    values = self._audio(previous, cancel, previous["count"] - take, take)
                    context.append((previous["role"], values))
                    used += len(values)
                    self.emit("learning_context", key="history_context", sample=row["id"], context_sample=previous["id"], generated_as_target=False)
                except (OSError, RuntimeError, ValueError) as exc:
                    self.emit("notice", key="sample_skipped", sample=previous["id"], reason=concise_error(exc))
                if used >= budget:
                    break
            context.reverse()
        return {"prompt": self._prompt(row), "source": source, "target": target, "ended": end == total, "context": tuple(context)}, end

    def _usable(self, row, cancel, held_out=False):
        try:
            return self.features(row, cancel, held_out)
        except Cancelled:
            raise
        except (OSError, RuntimeError, ValueError) as exc:
            self.store.db.execute("UPDATE samples SET learnable=0 WHERE id=?", (row["id"],))
            self.store.db.commit()
            self.emit("notice", key="sample_skipped", sample=row["id"], reason=concise_error(exc))
            return None

    def _evaluate(self, rows, cancel):
        torch = self.model.torch
        before, after = {}, {}
        self.candidate.eval()
        for index, row in enumerate(rows):
            check(cancel)
            self.emit("phase", key="validating", current=index, total=len(rows), unit="groups", split=row["split"])
            usable = self._usable(row, cancel, held_out=True)
            if usable is None:
                return None
            features, _ = usable
            with self.model.interruptible(cancel), torch.no_grad():
                base = float(self.model.loss(self.model.network, **features, rollout=True).item())
                candidate = float(self.model.loss(self.candidate, **features, rollout=True).item())
            if not math.isfinite(base) or not math.isfinite(candidate):
                raise YuanError("验证指标无效 / Validation measurements are not finite")
            before[row["group_id"]], after[row["group_id"]] = base, candidate
            self.emit("phase", key="validating", current=index + 1, total=len(rows), unit="groups", split=row["split"])
        return before, after

    def step(self, cancel):
        torch = self.model.torch
        row = self.store.next_sample("train")
        if row is None:
            self.emit("learning", key="waiting_data", steps=self.steps, accepted=self.model.accepted)
            return False
        usable = self._usable(row, cancel)
        if usable is None:
            return False
        features, cursor = usable
        self._prepare(cancel)
        check(cancel)
        self.emit("learning", key="training", steps=self.steps, accepted=self.model.accepted, sample=row["id"], group=row["group_id"], origin=row["origin"], split=row["split"], cursor=row["cursor"], seconds=row["seconds"], context=len(features["context"]))
        self.candidate.train().requires_grad_(True)
        try:
            with self.model.interruptible(cancel):
                self.optimizer.zero_grad(set_to_none=True)
                loss = self.model.loss(self.candidate, **features)
                if not torch.isfinite(loss):
                    self.candidate = self.optimizer = None
                    self.dirty = False
                    self.emit("notice", key="candidate_reset")
                    raise YuanError("学习损失无效 / Learning loss is not finite")
                loss.backward()
                check(cancel)
                parameters = sum(value.numel() for value in self.candidate.parameters())
                torch.nn.utils.clip_grad_norm_(self.candidate.parameters(), math.sqrt(parameters), error_if_nonfinite=True)
                self.optimizer.step()
                if any(not torch.isfinite(value).all() for value in self.candidate.parameters()):
                    self.candidate = self.optimizer = None
                    self.dirty = False
                    self.emit("notice", key="candidate_reset")
                    raise YuanError("更新产生无效数值 / Update produced non-finite values")
                self.training_loss = float(loss.item())
                self.steps += 1
                self.model.steps = self.steps
                self.dirty = True
            self.checkpoint(cancel)
            self.store.advance(row, cursor)
            rows = {split: self.store.held_out(split) for split in ("validation", "guard")}
            if any(not values for values in rows.values()):
                self.emit("learning", key="training_unvalidated", steps=self.steps, accepted=self.model.accepted, train=self.training_loss,
                          validation_groups=len(rows["validation"]), guard_groups=len(rows["guard"]))
                return True
            ids = [row["group_id"], *[sample["group_id"] for split in rows.values() for sample in split]]
            if len(ids) != len(set(ids)):
                raise YuanError("训练、验证与保护数据来源重叠 / Training, validation and guard sources overlap")
            self.emit("learning", key="validating", steps=self.steps, accepted=self.model.accepted)
            comparisons = {split: self._evaluate(values, cancel) for split, values in rows.items()}
            if any(value is None for value in comparisons.values()):
                self.emit("learning", key="training_unvalidated", steps=self.steps, accepted=self.model.accepted)
                return True
            epsilon = torch.finfo(self.model.dtype).eps
            metrics = {"train": self.training_loss, "groups": {}, "objective": "teacher-forced and autoregressive acoustic prediction", "conversation_verified": False}
            passed = True
            for split, (before, after) in comparisons.items():
                baseline = sum(before.values()) / len(before)
                updated = sum(after.values()) / len(after)
                tolerance = epsilon * max(1.0, abs(baseline)) * math.sqrt(len(before))
                passed = passed and updated < baseline - tolerance and all(after[key] <= value + epsilon * max(1.0, abs(value)) for key, value in before.items())
                metrics["before" if split == "validation" else "guard_before"] = baseline
                metrics["after" if split == "validation" else "guard_after"] = updated
                metrics["groups"][split] = {key: {"before": before[key], "after": after[key]} for key in before}
            check(cancel)
            if passed:
                self.model.promote(self.candidate, metrics, cancel)
                self.checkpoint(cancel)
            self.emit("learning", key="promoted" if passed else "kept", steps=self.steps, accepted=self.model.accepted, **metrics)
            return True
        finally:
            if self.optimizer is not None:
                self.optimizer.zero_grad(set_to_none=True)

class PublicAudio:
    def __init__(self, state, store, model, emit):
        self.store, self.model, self.emit = store, model, emit
        self.root = safe_path(state, "sources")
        self.root.mkdir(exist_ok=True)
        tracked = {row[0] for row in self.store.db.execute("SELECT path FROM sources WHERE path IS NOT NULL")}
        pending = {row[0] for row in self.store.db.execute("SELECT id FROM sources WHERE finished=0")}
        for path in self.root.iterdir():
            if path.is_file() and path.name not in tracked and path.stem not in pending and len(path.stem) == hashlib.sha1().digest_size * 2 and all(char in "0123456789abcdef" for char in path.stem):
                path.unlink(missing_ok=True)
        self.next_network = 0.0
        self.failures = 0
        self.empty_queries = 0
        self.duration = model.chunk_seconds
        self.next_language = int(store.setting("source_language", 0))
        self.network = Network()

    def query(self, cancel):
        language = ("Chinese", "English")[self.next_language % 2]
        key = "catalog_" + language
        root = "Category:Spoken " + language + " Wikipedia"
        catalog = self.store.setting(key, {})
        if not isinstance(catalog, dict) or not catalog.get("pending"):
            catalog = {"pending": [root], "visited": [], "continue": {}}
        current = catalog["pending"][0]
        continuation = catalog.get("continue", {})
        params = {"action": "query", "format": "json", "generator": "categorymembers", "gcmtitle": current,
                  "gcmtype": "file|subcat", "gcmlimit": str(min(500, max(1, math.isqrt(self.model.capacity() // self.model.hop)))),
                  "prop": "imageinfo|categories", "cllimit": "max", "iiprop": "url|size|mime|sha1|extmetadata"}
        if isinstance(continuation, dict):
            params.update({name: value for name, value in continuation.items() if name in ("continue", "gcmcontinue", "clcontinue", "iicontinue")})
        self.network.cancel = cancel
        result = self.network.json("https://commons.wikimedia.org/w/api.php?" + urllib.parse.urlencode(params))
        if not isinstance(result, dict) or "error" in result:
            raise YuanError("公开音频目录暂不可用 / Public audio catalog is temporarily unavailable")
        added = 0
        for page in result.get("query", {}).get("pages", {}).values():
            check(cancel)
            if page.get("ns") == 14:
                title = page.get("title")
                if isinstance(title, str) and title not in catalog["pending"] and title not in catalog["visited"]:
                    catalog["pending"].append(title)
                continue
            infos = page.get("imageinfo") or []
            if not infos:
                continue
            info = infos[0]
            metadata = info.get("extmetadata", {})
            categories = " ".join(str(item.get("title", "")) for item in page.get("categories", [])).lower()
            if any(value in categories for value in ("speech synthesis", "text-to-speech", "synthetic speech", "语音合成", "語音合成")):
                continue
            license_name = str(metadata.get("LicenseShortName", {}).get("value", "")).lower().replace("-", " ")
            license_parts = license_name.split()
            allowed_license = license_name in ("cc0", "cc0 1.0", "public domain", "public domain mark") or (
                license_parts[:2] == ["cc", "by"] and all(part == "sa" or part.replace(".", "", 1).isdigit() for part in license_parts[2:]))
            if not allowed_license:
                continue
            url = info.get("url", "")
            parsed = urllib.parse.urlparse(url)
            if parsed.scheme != "https" or parsed.hostname != "upload.wikimedia.org" or not (str(info.get("mime", "")).startswith("audio/") or info.get("mime") == "application/ogg"):
                continue
            sha1 = str(info.get("sha1", "")).lower()
            if len(sha1) != 40 or any(char not in "0123456789abcdef" for char in sha1):
                try:
                    number = int(sha1, 36)
                    if number < 0 or number.bit_length() > 160:
                        continue
                    sha1 = format(number, "040x")
                except ValueError:
                    continue
            try:
                size = int(info.get("size", 0))
            except (ValueError, TypeError):
                continue
            if size <= 0:
                continue
            provenance = {"license": metadata.get("LicenseShortName", {}).get("value", ""), "license_url": metadata.get("LicenseUrl", {}).get("value", ""),
                          "artist": metadata.get("Artist", {}).get("value", ""), "attribution": metadata.get("Attribution", {}).get("value", ""),
                          "page": info.get("descriptionurl", ""), "title": page.get("title", ""), "size": size, "sha1": sha1, "mime": info.get("mime"), "language": language}
            cursor = self.store.db.execute("INSERT OR IGNORE INTO sources(id,url,metadata,created) VALUES(?,?,?,?)", (sha1, url, json.dumps(provenance, ensure_ascii=False), time.time()))
            added += max(0, cursor.rowcount)
        self.store.db.commit()
        if result.get("continue"):
            catalog["continue"] = result["continue"]
        else:
            catalog["visited"].append(catalog["pending"].pop(0))
            catalog["continue"] = {}
        self.store.set_setting(key, catalog)
        self.next_language += 1
        self.store.set_setting("source_language", self.next_language)
        self.emit("source_catalog", language=language, category=current, added=added, pending=len(catalog["pending"]))
        return added

    def step(self, cancel):
        import soundfile as sf
        import psutil
        check(cancel)
        unfinished = self.store.db.execute("SELECT * FROM sources WHERE finished=0 AND path IS NOT NULL ORDER BY offset,created LIMIT 1").fetchone()
        groups = self.store.db.execute("SELECT count(DISTINCT group_id) FROM samples WHERE learnable=1 AND generated=0 AND count>1").fetchone()[0]
        missing = self.store.db.execute("SELECT * FROM sources WHERE finished=0 AND path IS NULL ORDER BY created,id LIMIT 1").fetchone()
        download_needed = unfinished is None or groups < len(("train", "validation", "guard"))
        if download_needed and time.monotonic() >= self.next_network:
            start = time.monotonic()
            self.emit("network", key="network")
            self.network.cancel = cancel
            try:
                added = None
                if missing is None:
                    added = self.query(cancel)
                    missing = self.store.db.execute("SELECT * FROM sources WHERE finished=0 AND path IS NULL ORDER BY created,id LIMIT 1").fetchone()
                self.empty_queries = self.empty_queries + 1 if added == 0 and missing is None else 0
                if missing is not None:
                    metadata = json.loads(missing["metadata"])
                    budget = min(psutil.virtual_memory().available, shutil.disk_usage(self.root).free // 2)
                    size = int(metadata["size"])
                    if size <= 0 or size > budget:
                        self.emit("notice", key="source_skipped", source=missing["id"], bytes=size, budget=budget)
                        self.store.db.execute("UPDATE sources SET created=? WHERE id=?", (time.time(), missing["id"]))
                        self.store.db.commit()
                    else:
                        suffix = Path(urllib.parse.urlparse(missing["url"]).path).suffix.lower()
                        if suffix not in (".flac", ".ogg", ".oga", ".wav", ".mp3", ".opus"):
                            self.store.db.execute("UPDATE sources SET finished=1,path=NULL WHERE id=?", (missing["id"],))
                            self.store.db.commit()
                        else:
                            target = self.root / (missing["id"] + suffix)
                            self.emit("source", url=missing["url"], metadata=metadata, file=target.name)
                            self.network.download(missing["url"], target, size, metadata["sha1"], algorithm="sha1", max_bytes=budget,
                                                     progress=lambda done, total: self.emit("phase", key="network", current=done, total=total, unit="bytes", file=target.name))
                            check(cancel)
                            self.store.db.execute("UPDATE sources SET path=? WHERE id=?", (target.name, missing["id"]))
                            self.store.db.commit()
                            unfinished = self.store.db.execute("SELECT * FROM sources WHERE id=?", (missing["id"],)).fetchone()
                self.failures = 0
                self.emit("network", key="available")
            except Cancelled:
                raise
            except Exception as exc:
                self.failures += 1
                self.emit("network", key="offline", reason=concise_error(exc))
            self.duration = max(tick(), time.monotonic() - start, math.sqrt(self.duration))
            self.next_network = time.monotonic() + self.duration * (self.failures + self.empty_queries + 1) ** 2
        if unfinished is None:
            return False
        path = safe_path(self.root, unfinished["path"])
        if not path.is_file():
            self.store.db.execute("UPDATE sources SET path=NULL,offset=0 WHERE id=?", (unfinished["id"],))
            self.store.db.commit()
            return False
        try:
            with sf.SoundFile(str(path)) as stream:
                if unfinished["offset"] >= stream.frames:
                    self.store.db.execute("UPDATE sources SET finished=1,path=NULL WHERE id=?", (unfinished["id"],))
                    self.store.db.commit()
                    path.unlink(missing_ok=True)
                    return False
                stream.seek(unfinished["offset"])
                take = max(1, int(self.model.chunk_seconds * stream.samplerate))
                waveform = stream.read(take, dtype="float32", always_2d=True).mean(axis=1)
                offset = stream.tell()
                completed = offset >= stream.frames
                rate = int(stream.samplerate)
            check(cancel)
            if waveform.size:
                provenance = json.loads(unfinished["metadata"])
                sample_metadata = {"source": unfinished["id"], "url": unfinished["url"], "page": provenance.get("page", ""), "title": provenance.get("title", ""),
                                   "license": provenance.get("license", ""), "license_url": provenance.get("license_url", ""), "artist": provenance.get("artist", ""),
                                   "attribution": provenance.get("attribution", ""), "source_offset": unfinished["offset"], "source_end": offset}
                self.store.add("public-" + unfinished["id"], "reference", self.model.normalize(waveform, rate), self.model.rate, "public", cancel, metadata=sample_metadata)
            self.store.db.execute("UPDATE sources SET offset=?,finished=?,path=? WHERE id=?", (offset, int(completed), None if completed else unfinished["path"], unfinished["id"]))
            self.store.db.commit()
            if completed:
                path.unlink(missing_ok=True)
            return True
        except (sf.LibsndfileError, ValueError) as exc:
            self.emit("notice", key="source_skipped", reason=concise_error(exc), source=unfinished["id"])
            self.store.db.execute("UPDATE sources SET finished=1,path=NULL WHERE id=?", (unfinished["id"],))
            self.store.db.commit()
            path.unlink(missing_ok=True)
            return False

class SampleRing:
    def __init__(self, capacity, rate=1):
        import numpy as np
        self.buffer = np.empty(max(1, int(capacity)), dtype=np.float32)
        self.rate = float(rate)
        self.read_index = self.write_index = self.count = 0
        self.lock = threading.Lock()
        self.overflows = self.dropped = 0
        self.timestamp = 0.0

    def write(self, values, timestamp=None):
        size = len(values)
        if not size:
            return
        if not self.lock.acquire(blocking=False):
            self.overflows += 1
            self.dropped += size
            return
        try:
            timestamp = time.monotonic() if timestamp is None else float(timestamp)
            if size > len(self.buffer):
                discarded = size - len(self.buffer)
                values = values[discarded:]
                timestamp += discarded / self.rate
                self.overflows += 1
                self.dropped += discarded
                size = len(values)
            missing = max(0, size - (len(self.buffer) - self.count))
            if missing:
                self.overflows += 1
                self.dropped += missing
                self.read_index = (self.read_index + missing) % len(self.buffer)
                self.count -= missing
                self.timestamp += missing / self.rate
            if not self.count:
                self.timestamp = timestamp
            first = min(size, len(self.buffer) - self.write_index)
            self.buffer[self.write_index:self.write_index + first] = values[:first]
            self.buffer[:size - first] = values[first:]
            self.write_index = (self.write_index + size) % len(self.buffer)
            self.count += size
        finally:
            self.lock.release()

    def read(self, size):
        import numpy as np
        with self.lock:
            take = min(max(0, int(size)), self.count)
            result = np.empty(take, dtype=np.float32)
            first = min(take, len(self.buffer) - self.read_index)
            result[:first] = self.buffer[self.read_index:self.read_index + first]
            result[first:] = self.buffer[:take - first]
            timestamp = self.timestamp
            self.read_index = (self.read_index + take) % len(self.buffer)
            self.count -= take
            self.timestamp += take / self.rate
            return result, timestamp

class AudioPolicy:
    def __init__(self, model, devices, emit):
        import numpy as np
        import psutil
        self.path = safe_path(model.state, "audio.json")
        saved = read_json(self.path)
        overrides = saved.get("overrides", {})
        if not isinstance(overrides, dict):
            overrides = {}
        self.overrides = overrides
        self.valid_overrides = {}
        frame_seconds = model.hop / model.rate
        latency = max(frame_seconds, *(float(device.get("default_high_" + direction + "_latency", frame_seconds))
                                      for device, direction in zip(devices, ("input", "output"))))
        memory_seconds = psutil.virtual_memory().available / (model.rate * np.dtype(np.float32).itemsize)
        self.frame_size = model.hop
        self.segment_seconds = self.number("segment_seconds", min(model.capacity() // 2, model.input_budget or model.capacity() // 2) / model.rate, frame_seconds, min(model.capacity() / model.rate, memory_seconds / 16))
        self.pause_seconds = self.number("pause_seconds", (model.chunk_seconds ** 2 * frame_seconds) ** (1 / 3), frame_seconds, self.segment_seconds)
        self.onset_seconds = self.number("onset_seconds", math.sqrt(frame_seconds), frame_seconds, self.pause_seconds)
        self.buffer_seconds = self.number("buffer_seconds", max(model.chunk_seconds, latency * 2), frame_seconds, max(frame_seconds, memory_seconds / 16))
        self.echo_seconds = self.number("echo_seconds", max(latency * 2, self.pause_seconds), frame_seconds, self.segment_seconds)
        trials = max(1, self.echo_seconds * model.rate)
        self.echo_correlation = self.number("echo_correlation", min(1.0, math.sqrt(2 * math.log(trials / np.finfo(np.float32).eps) / self.frame_size)), np.finfo(np.float32).eps, 1.0)
        self.reconnect_seconds = self.number("reconnect_seconds", math.sqrt(model.chunk_seconds * latency), frame_seconds, model.capacity_seconds)
        self.latency = self.number("latency_seconds", math.sqrt(frame_seconds * latency), frame_seconds, max(frame_seconds, latency))
        effective = {name: value for name, value in vars(self).items() if isinstance(value, (int, float))}
        atomic_json(self.path, {"overrides": self.valid_overrides, "effective": effective})
        emit("audio_policy", **effective)

    def number(self, key, default, lower, upper):
        upper = max(lower, upper)
        value = self.overrides.get(key, default)
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
            value = default
        elif key in self.overrides:
            self.valid_overrides[key] = value
        return float(max(lower, min(upper, value)))

class SpeechGate:
    def __init__(self, rate, frame_size, chunk_seconds, max_seconds, pause_seconds=None, onset_seconds=None):
        self.rate, self.frame_size = int(rate), int(frame_size)
        self.frame_seconds = self.frame_size / self.rate
        self.pause = max(self.frame_seconds, pause_seconds or (chunk_seconds ** 2 * self.frame_seconds) ** (1 / 3))
        self.pause_limit = max(self.pause, chunk_seconds)
        self.max_frames = max(1, int(math.ceil(max_seconds / self.frame_seconds)))
        self.start_needed = max(1, int(math.ceil((onset_seconds or math.sqrt(self.frame_seconds)) / self.frame_seconds)))
        self.history = deque(maxlen=max(self.start_needed * 2, int(math.ceil(chunk_seconds / self.frame_seconds))))
        self.preroll = deque(maxlen=min(self.max_frames, max(self.start_needed, int(math.ceil(self.pause / self.frame_seconds)))))
        self.pauses = deque(maxlen=max(1, math.isqrt(self.max_frames)))
        self.bootstrap_spectrum = None
        self.frames = []
        self.silence = 0
        self.active = False
        self.limited = False
        self.start_count = 0
        self.confidence = 0.0

    def _threshold(self):
        import numpy as np
        if len(self.history) < self.start_needed:
            return math.inf
        values = np.asarray(self.history, dtype=np.float64)
        lower = values[values <= np.median(values)]
        median = float(np.median(lower))
        deviation = float(np.median(np.abs(lower - median)))
        floor = float(np.finfo(np.float32).eps * math.sqrt(self.rate))
        spread = max(deviation, median / max(1.0, math.sqrt(len(values))), floor)
        return median + spread * max(1.0, math.log2(len(values) + 1))

    def bootstrap_voice(self, frame, level):
        import numpy as np
        floor = float(np.finfo(np.float32).eps * math.sqrt(self.rate))
        if level <= floor:
            self.bootstrap_spectrum = None
            return False, 0.0
        if len(frame) < 4:
            return True, 1.0
        crossings = float(np.mean(np.signbit(frame[1:]) != np.signbit(frame[:-1])))
        window = np.hanning(len(frame)).astype(np.float64)
        power = np.abs(np.fft.rfft(frame.astype(np.float64) * window)) ** 2
        total = float(power.sum())
        if total <= np.finfo(np.float64).tiny:
            self.bootstrap_spectrum = None
            return False, 0.0
        distribution = power / total
        entropy = float(-(distribution * np.log(np.maximum(distribution, np.finfo(np.float64).tiny))).sum() / math.log(max(2, len(distribution))))
        spectrum = np.sqrt(distribution)
        if self.bootstrap_spectrum is None or len(self.bootstrap_spectrum) != len(spectrum):
            flux = 1.0
        else:
            flux = float(np.sqrt(np.mean((spectrum - self.bootstrap_spectrum) ** 2)))
        self.bootstrap_spectrum = spectrum
        zcr_limit = min(0.5, max(1 / len(frame), math.sqrt(self.frame_seconds)))
        entropy_limit = max(0.5, 1 - 1 / math.sqrt(max(2.0, math.log2(len(distribution) + 1))))
        flux_floor = 1 / max(2.0, math.sqrt(len(distribution)))
        voiced = crossings <= zcr_limit or entropy <= entropy_limit or flux >= flux_floor
        score = max(0.0, min(1.0, max((zcr_limit - crossings) / max(zcr_limit, np.finfo(np.float64).eps),
                                      (entropy_limit - entropy) / max(entropy_limit, np.finfo(np.float64).eps),
                                      flux / max(flux_floor, np.finfo(np.float64).eps) - 1)))
        return voiced, score

    def push(self, frame):
        import numpy as np
        frame = np.asarray(frame, dtype=np.float32).reshape(-1)
        if not frame.size or not np.isfinite(frame).all():
            raise YuanError("检测音频无效 / Invalid detector audio")
        frame = frame - frame.mean(dtype=np.float64)
        level = float(np.sqrt(np.mean(frame.astype(np.float64) ** 2)))
        threshold = self._threshold()
        floor = float(np.finfo(np.float32).eps * math.sqrt(self.rate))
        if math.isfinite(threshold):
            voiced = level > threshold
            self.confidence = max(0.0, min(1.0, (level - threshold) / max(floor, abs(threshold))))
        else:
            voiced, self.confidence = self.bootstrap_voice(frame, level)
        self.limited = False
        if not self.active:
            self.preroll.append(frame.copy())
            if not voiced:
                self.history.append(level)
            self.start_count = self.start_count + 1 if voiced else 0
            if self.start_count < self.start_needed:
                return None
            self.frames = list(self.preroll)
            self.preroll.clear()
            self.active = True
            self.silence = 0
            self.start_count = 0
        else:
            self.frames.append(frame.copy())
            if voiced:
                if self.silence:
                    self.pauses.append(self.silence * self.frame_seconds)
                    middle = sorted(self.pauses)[len(self.pauses) // 2]
                    self.pause = min(self.pause_limit, max(self.frame_seconds, math.sqrt(max(self.frame_seconds, middle) * self.pause) + self.frame_seconds))
                self.silence = 0
            else:
                self.silence += 1
                self.history.append(level)
        self.limited = len(self.frames) >= self.max_frames
        ended = self.silence * self.frame_seconds >= self.pause
        if not ended and not self.limited:
            return None
        result = self.flush()
        if self.limited and not ended:
            self.active = True
        return result

    def flush(self):
        import numpy as np
        frames = self.frames if self.active else list(self.preroll) if self.start_count else []
        trim = max(0, self.silence - 1)
        if trim:
            frames = frames[:-trim]
        result = np.concatenate(frames) if frames else None
        self.frames = []
        self.preroll.clear()
        self.active = False
        self.silence = self.start_count = 0
        return result

class ReplyCancel:
    def __init__(self, parent, capture, revision):
        self.parent, self.capture, self.revision = parent, capture, revision

    def is_set(self):
        return self.parent.is_set() or self.capture.stop_event.is_set() or self.capture.revision != self.revision or self.capture.speaking or not self.capture.connected

    def wait(self, timeout):
        deadline = time.monotonic() + max(0.0, timeout)
        while not self.is_set():
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                break
            self.parent.wait(min(remaining, math.sqrt(tick())))
        return self.is_set()

class Playback:
    def __init__(self, waveform, reference, rate, reference_rate, cancel):
        self.waveform, self.reference = waveform, reference
        self.rate, self.reference_rate, self.cancel = rate, reference_rate, cancel
        self.cursor = 0
        self.started_at = None
        self.drain_at = None
        self.interrupted = False
        self.discontinuous = False

    def played(self):
        if self.started_at is None:
            return 0
        return max(0, min(self.cursor, int((time.monotonic() - self.started_at) * self.rate)))

class EchoSuppressor:
    def __init__(self, rate, policy):
        self.rate, self.policy = rate, policy
        self.correlation = 0.0
        self.reduction = 0.0

    def process(self, frame, timestamp, playback):
        import numpy as np
        self.correlation = self.reduction = 0.0
        if playback is None or playback.started_at is None:
            return frame, False
        relative = timestamp - playback.started_at
        rendered = playback.cursor / playback.rate
        overlap = relative + len(frame) / self.rate >= 0 and relative <= rendered + self.policy.echo_seconds
        if not overlap:
            return frame, False
        if playback.reference_rate != self.rate or playback.discontinuous:
            return frame, True
        n = len(frame)
        if n < 2:
            return frame, True
        position = int(round(relative * self.rate))
        start = max(0, position - int(math.ceil(self.policy.echo_seconds * self.rate)))
        end = min(len(playback.reference), int(math.ceil(rendered * self.rate)), position + n)
        reference = playback.reference[start:end].astype(np.float64)
        microphone = frame.astype(np.float64)
        microphone -= microphone.mean()
        energy = float(np.dot(microphone, microphone))
        if len(reference) < n or energy <= np.finfo(np.float32).eps ** 2 * n:
            return frame, True
        size = 1 << (len(reference) + n - 2).bit_length()
        cross = np.fft.irfft(np.fft.rfft(reference, size) * np.fft.rfft(microphone[::-1], size), size)[n - 1:len(reference)]
        cumulative = np.concatenate(([0.0], np.cumsum(reference)))
        squares = np.concatenate(([0.0], np.cumsum(reference * reference)))
        sums = cumulative[n:] - cumulative[:-n]
        energies = np.maximum(0.0, squares[n:] - squares[:-n] - sums * sums / n)
        denominator = np.sqrt(np.maximum(np.finfo(np.float64).tiny, energies * energy))
        scores = np.abs(cross) / denominator
        best = int(np.argmax(scores))
        self.correlation = min(1.0, float(scores[best]))
        if self.correlation < self.policy.echo_correlation or energies[best] <= np.finfo(np.float32).eps ** 2 * n:
            return frame, True
        selected = reference[best:best + n] - sums[best] / n
        gain = float(cross[best] / energies[best])
        result = microphone - gain * selected
        self.reduction = max(0.0, min(1.0, 1 - float(np.dot(result, result)) / energy))
        return np.ascontiguousarray(result, dtype=np.float32), True

class AudioDevices:
    def __init__(self, model, emit):
        import sounddevice as sd
        import soxr
        self.sd, self.soxr, self.model, self.emit = sd, soxr, model, emit
        self.streams = {}
        self.stream_lock = threading.RLock()
        self.faults = 0
        self.input_faults = 0
        self.output_faults = 0
        self.vad_rate = model.rate
        self.frame_size = model.hop
        self.playback = None
        self.reference = None
        self.ring = None
        self.policy = None
        self.output_rate = model.rate
        self.input_rate = model.rate
        self.input_latency = self.output_latency = model.hop / model.rate
        self.capture = None

    def defaults(self):
        devices = self.sd.query_devices()
        defaults = self.sd.default.device
        selected = []
        for position, direction in enumerate(("input", "output")):
            index = defaults[position]
            if index is None or index < 0 or index >= len(devices) or devices[index]["max_" + direction + "_channels"] < 1:
                options = [number for number, device in enumerate(devices) if device["max_" + direction + "_channels"] > 0]
                if not options:
                    raise YuanError("等待可用麦克风与扬声器 / Waiting for a microphone and speaker")
                index = options[0]
            selected.append(int(index))
        return selected, [devices[index] for index in selected]

    def probe(self):
        defaults, _ = self.defaults()
        all_devices = self.sd.query_devices()
        indices, devices = [], []
        for default, direction in zip(defaults, ("input", "output")):
            options = [default, *[index for index, device in enumerate(all_devices) if index != default and device["max_" + direction + "_channels"] > 0]]
            selected = None
            reasons = []
            for index in options:
                device = dict(all_devices[index])
                maximum = int(device["max_" + direction + "_channels"])
                for channels in dict.fromkeys((1, min(2, maximum))):
                    for rate in dict.fromkeys((int(round(device["default_samplerate"])), self.model.rate)):
                        try:
                            getattr(self.sd, "check_" + direction + "_settings")(device=index, channels=channels, dtype="float32", samplerate=rate)
                            device.update(default_samplerate=rate, selected_channels=channels)
                            selected = index, device
                            break
                        except Exception as exc:
                            reasons.append(concise_error(exc))
                    if selected:
                        break
                if selected:
                    break
            if selected is None:
                raise YuanError("没有可用的音频设备配置 / No usable audio device configuration: " + "; ".join(dict.fromkeys(reasons)))
            indices.append(selected[0])
            devices.append(selected[1])
        self.emit("devices", input=devices[0]["name"], output=devices[1]["name"], input_rate=int(devices[0]["default_samplerate"]), output_rate=int(devices[1]["default_samplerate"]),
                  input_channels=devices[0]["selected_channels"], output_channels=devices[1]["selected_channels"], continuous=True)
        return indices, devices

    def abort(self):
        playback = self.playback
        if playback is not None:
            playback.interrupted = True
        self.playback = None
        with self.stream_lock:
            streams = tuple(self.streams.values())
        for stream in streams:
            try:
                stream.abort(ignore_errors=True)
            except Exception:
                pass

    def close_streams(self):
        with self.stream_lock:
            streams = tuple(self.streams.values())
            self.streams.clear()
        reasons = []
        for stream in streams:
            try:
                stream.abort(ignore_errors=True)
            except Exception as exc:
                reasons.append(concise_error(exc))
            try:
                stream.close(ignore_errors=True)
            except Exception as exc:
                reasons.append(concise_error(exc))
        if reasons:
            self.emit("notice", key="capture_recover", component="stream_cleanup", reason="; ".join(dict.fromkeys(reasons)))

    def timestamp(self, timing, key, fallback):
        now = time.monotonic()
        current = float(getattr(timing, "currentTime", 0.0))
        value = float(getattr(timing, key, 0.0))
        if current and value and math.isfinite(current) and math.isfinite(value):
            return now + value - current
        return now + fallback

    def input_callback(self, indata, frames, timing, status):
        if status and (status.input_overflow or status.input_underflow):
            self.input_faults += 1
            self.faults += 1
        timestamp = self.timestamp(timing, "inputBufferAdcTime", -max(self.input_latency, frames / self.input_rate))
        values = indata[:, 0] if indata.shape[1] == 1 else indata.mean(axis=1)
        self.ring.write(values, timestamp)

    def output_callback(self, outdata, frames, timing, status):
        outdata.fill(0)
        output_fault = bool(status and (status.output_underflow or status.output_overflow))
        if output_fault:
            self.output_faults += 1
            self.faults += 1
        playback = self.playback
        if playback is None:
            return
        if output_fault:
            playback.discontinuous = True
        if playback.cancel.is_set():
            playback.interrupted = True
            return
        if status and status.output_overflow:
            return
        count = min(frames, len(playback.waveform) - playback.cursor)
        if count <= 0:
            return
        start = playback.cursor
        timestamp = self.timestamp(timing, "outputBufferDacTime", self.output_latency)
        if playback.started_at is None:
            playback.started_at = timestamp
        outdata[:count, :] = playback.waveform[start:start + count, None]
        playback.cursor += count
        playback.drain_at = timestamp + count / playback.rate

    def duplex_callback(self, indata, outdata, frames, timing, status):
        self.output_callback(outdata, frames, timing, status)
        self.input_callback(indata, frames, timing, status)

    def open_streams(self, cancel):
        indices, devices = self.probe()
        self.policy = AudioPolicy(self.model, devices, self.emit)
        self.playback = self.reference = None
        reasons = []
        common_rates = dict.fromkeys((int(devices[0]["default_samplerate"]), int(devices[1]["default_samplerate"]), self.model.rate))
        for rate in common_rates:
            check(cancel)
            stream = None
            try:
                self.input_rate = self.output_rate = rate
                self.ring = SampleRing(math.ceil(rate * self.policy.buffer_seconds), rate)
                stream = self.sd.Stream(device=tuple(indices), samplerate=rate, channels=tuple(device["selected_channels"] for device in devices), dtype="float32",
                                        blocksize=0, latency=self.policy.latency, callback=self.duplex_callback, never_drop_input=True)
                with self.stream_lock:
                    check(cancel)
                    self.streams["duplex"] = stream
                    reported = stream.latency
                    self.input_latency, self.output_latency = reported if isinstance(reported, (tuple, list)) else (reported, reported)
                    stream.start()
                self.emit("devices", input_rate=rate, output_rate=rate, input_latency=self.input_latency, output_latency=self.output_latency, transport="duplex", continuous=True)
                return
            except Cancelled:
                if stream is not None:
                    stream.close(ignore_errors=True)
                self.close_streams()
                raise
            except Exception as exc:
                reasons.append(concise_error(exc))
                if stream is not None:
                    stream.close(ignore_errors=True)
                with self.stream_lock:
                    self.streams.clear()
        self.input_rate = int(devices[0]["default_samplerate"])
        self.output_rate = int(devices[1]["default_samplerate"])
        self.ring = SampleRing(math.ceil(self.input_rate * self.policy.buffer_seconds), self.input_rate)
        try:
            for direction, index, device in zip(("input", "output"), indices, devices):
                check(cancel)
                constructor = self.sd.InputStream if direction == "input" else self.sd.OutputStream
                stream = constructor(device=index, samplerate=int(device["default_samplerate"]), channels=device["selected_channels"], dtype="float32",
                                     blocksize=0, latency=self.policy.latency, callback=self.input_callback if direction == "input" else self.output_callback)
                with self.stream_lock:
                    self.streams[direction] = stream
                    setattr(self, direction + "_latency", float(stream.latency))
                    check(cancel)
                    stream.start()
            self.emit("devices", input_rate=self.input_rate, output_rate=self.output_rate, input_latency=self.input_latency, output_latency=self.output_latency, transport="separate-continuous", continuous=True)
        except BaseException:
            self.close_streams()
            raise
        self.emit("notice", key="full_duplex", component="separate_streams", reasons=reasons)

    def active(self):
        with self.stream_lock:
            return bool(self.streams) and all(stream.active for stream in self.streams.values())

    def play(self, waveform, rate, cancel):
        import numpy as np
        check(cancel)
        original = np.asarray(waveform, dtype=np.float32).reshape(-1)
        if not original.size or not np.isfinite(original).all():
            raise YuanError("播放音频无效 / Invalid playback audio")
        if not self.active():
            raise YuanError("持续音频流不可用 / Continuous audio stream is unavailable")
        values = self.soxr.resample(original, rate, self.output_rate).astype(np.float32) if rate != self.output_rate else original.copy()
        values = np.ascontiguousarray(np.clip(values, -1, 1), dtype=np.float32)
        reference = self.soxr.resample(values, self.output_rate, self.vad_rate).astype(np.float32) if self.output_rate != self.vad_rate else values
        playback = Playback(values, reference, self.output_rate, self.vad_rate, cancel)
        self.reference = self.playback = playback
        self.emit("status", key="speaking", id=self.capture.session_id if self.capture else None)
        interval = max(self.frame_size / self.vad_rate, math.sqrt(tick()))
        try:
            while True:
                if cancel.is_set():
                    playback.interrupted = True
                    break
                if not self.active():
                    playback.interrupted = True
                    raise YuanError("持续音频流已中断 / Continuous audio stream was interrupted")
                if playback.cursor == len(values) and playback.drain_at is not None and time.monotonic() >= playback.drain_at:
                    break
                cancel.wait(interval)
        finally:
            if self.playback is playback:
                self.playback = None
        played = min(len(original), int(playback.played() * rate / self.output_rate)) if playback.interrupted else len(original)
        self.emit("audio", id=self.capture.session_id if self.capture else None, output_seconds=played / rate,
                  interrupted=playback.interrupted, playback_discontinuity=playback.discontinuous, continuous=self.active())
        return original[:played].copy(), playback.interrupted

class CaptureSession:
    def __init__(self, devices, session_id, parent, emit):
        self.devices, self.model, self.session_id, self.parent, self.emit = devices, devices.model, session_id, parent, emit
        self.stop_event = threading.Event()
        self.wake = threading.Event()
        self.connected = False
        self.speaking = False
        self.revision = 0
        self.last_row = 0
        self.saved = self.consumed = 0
        self.thread = threading.Thread(target=self.run, daemon=True, name="YuanCapture")
        self.devices.capture = self

    def start(self):
        self.thread.start()
        return self

    def is_set(self):
        return self.parent.is_set() or self.stop_event.is_set()

    def wait(self, timeout):
        return self.stop_event.wait(timeout) or self.parent.is_set()

    def next(self, store):
        while not self.is_set():
            row = store.db.execute("SELECT rowid AS sequence,* FROM samples WHERE group_id=? AND role='user' AND rowid>? ORDER BY rowid LIMIT 1", (self.session_id, self.last_row)).fetchone()
            if row is not None:
                self.last_row = row["sequence"]
                self.consumed += 1
                return row
            if not self.thread.is_alive():
                raise YuanError("收音任务已停止 / Audio capture worker stopped")
            self.wake.wait(math.sqrt(tick()))
            self.wake.clear()
        raise Cancelled()

    def stop(self):
        self.stop_event.set()
        self.devices.abort()
        self.wake.set()
        while self.thread.is_alive():
            self.thread.join(timeout=max(math.sqrt(tick()), self.model.chunk_seconds))
            if self.thread.is_alive():
                self.emit("notice", key="capture_wait")
        if self.devices.capture is self:
            self.devices.capture = None

    def run(self):
        store = None
        try:
            store = AudioStore(self.model.state, recover=False)
            while not self.is_set():
                try:
                    self.devices.open_streams(self)
                    self.connected = True
                    self.emit("status", key="listening", id=self.session_id)
                    self.emit("audio", id=self.session_id, continuous=True)
                    self.emit("notice", key="echo_note")
                    self.collect(store)
                except Cancelled:
                    break
                except Exception as exc:
                    self.emit("status", key="capture_recover", id=self.session_id)
                    self.emit("notice", key="capture_recover", reason=concise_error(exc))
                finally:
                    self.connected = self.speaking = False
                    self.emit("audio", id=self.session_id, continuous=False, speech_active=False, level=0.0)
                    self.revision += 1
                    self.devices.abort()
                    self.devices.close_streams()
                    self.wake.set()
                if not self.is_set():
                    self.wait(self.devices.policy.reconnect_seconds if self.devices.policy else math.sqrt(self.model.chunk_seconds))
        except Exception as exc:
            self.emit("notice", key="capture_recover", reason=concise_error(exc))
        finally:
            self.connected = self.speaking = False
            if store is not None:
                try:
                    store.close()
                except (OSError, sqlite3.Error) as exc:
                    self.emit("notice", key="history_full", reason=concise_error(exc))
            self.emit("audio", id=self.session_id, continuous=False, level=0.0, recorded=0.0)
            self.emit("capture_stopped", id=self.session_id)
            self.wake.set()

    def collect(self, store):
        import numpy as np
        devices, model, policy = self.devices, self.model, self.devices.policy
        resampler = devices.soxr.ResampleStream(devices.input_rate, model.rate, 1, dtype="float32")
        gate = SpeechGate(model.rate, policy.frame_size, model.chunk_seconds, policy.segment_seconds, policy.pause_seconds, policy.onset_seconds)
        echo = EchoSuppressor(model.rate, policy)
        pending = np.empty(0, dtype=np.float32)
        origin = None
        position = 0
        prior_faults = devices.input_faults + devices.ring.overflows
        prior_output_faults = devices.output_faults
        overlap_until = -math.inf
        segment_overlap = False
        segment_gap = False
        last_levels = 0.0
        segment_start = None
        def save(values, timestamp, final=False):
            nonlocal segment_overlap, segment_gap, segment_start
            if values is None or not len(values):
                return
            processed = model.normalize(values, model.rate)
            created = time.time() + timestamp - time.monotonic()
            metadata = {"revision": self.revision, "playback_overlap": segment_overlap, "capture_gap": segment_gap, "limited": gate.limited, "final": final}
            try:
                sample = store.add(self.session_id, "user", processed, model.rate, "local", eligible=not segment_overlap and not segment_gap, created=created, metadata=metadata)
                self.saved += 1
                self.emit("capture_saved", id=self.session_id, sample=sample, seconds=len(processed) / model.rate, learnable=not segment_overlap and not segment_gap, **metadata)
            except (OSError, sqlite3.Error, YuanError) as exc:
                self.emit("notice", key="history_full", reason=concise_error(exc), lost_seconds=len(processed) / model.rate)
            self.wake.set()
            segment_overlap = segment_gap = False
            segment_start = None
        def consume(converted, final=False):
            nonlocal pending, position, overlap_until, segment_overlap, segment_gap, segment_start, last_levels
            pending = np.concatenate((pending, converted))
            while len(pending) >= policy.frame_size or final and len(pending):
                take = min(len(pending), policy.frame_size)
                frame, pending = pending[:take], pending[take:]
                timestamp = origin + position / model.rate
                position += take
                if not np.isfinite(frame).all():
                    devices.input_faults += 1
                    devices.faults += 1
                    segment_gap = True
                    continue
                frame, overlap = echo.process(frame, timestamp, devices.reference)
                if overlap:
                    overlap_until = timestamp + gate.preroll.maxlen * gate.frame_seconds
                before = gate.active
                result = gate.push(frame)
                if not before and (gate.active or result is not None):
                    self.revision += 1
                    segment_start = timestamp + take / model.rate - (sum(len(value) for value in gate.frames) if result is None else len(result)) / model.rate
                if before or gate.active or result is not None:
                    segment_overlap = segment_overlap or timestamp <= overlap_until
                self.speaking = gate.active
                if result is not None:
                    save(result, segment_start if segment_start is not None else timestamp - len(result) / model.rate)
                    if gate.active:
                        self.revision += 1
                        segment_start = timestamp + take / model.rate
                now = time.monotonic()
                if now - last_levels >= math.sqrt(gate.frame_seconds):
                    last_levels = now
                    self.emit("audio", id=self.session_id, level=float(np.sqrt(np.mean(frame.astype(np.float64) ** 2))), probability=gate.confidence, faults=devices.faults + devices.ring.overflows,
                              input_faults=devices.input_faults + devices.ring.overflows, output_faults=devices.output_faults, recorded=sum(len(value) for value in gate.frames) / model.rate, continuous=True, speech_active=gate.active,
                              pending=max(0, self.saved - self.consumed), dropped_samples=devices.ring.dropped, echo_correlation=echo.correlation, echo_reduction=echo.reduction, playback_overlap=overlap)
        try:
            while not self.is_set():
                faults = devices.input_faults + devices.ring.overflows
                if devices.output_faults != prior_output_faults:
                    prior_output_faults = devices.output_faults
                    self.emit("notice", key="playback_gap", id=self.session_id, output_faults=prior_output_faults)
                if faults != prior_faults:
                    segment_gap = True
                    if origin is not None:
                        save(gate.flush(), segment_start if segment_start is not None else origin + position / model.rate, final=True)
                    segment_gap = True
                    resampler.clear()
                    pending = np.empty(0, dtype=np.float32)
                    origin = None
                    position = 0
                    self.speaking = False
                    self.revision += 1
                    self.emit("notice", key="capture_gap", faults=faults, dropped_samples=devices.ring.dropped)
                    prior_faults = faults
                raw, timestamp = devices.ring.read(max(1, math.ceil(policy.frame_size * devices.input_rate / model.rate)))
                if raw.size:
                    if origin is None:
                        origin = timestamp
                    consume(resampler.resample_chunk(raw))
                else:
                    if not devices.active():
                        raise YuanError("收音流已中断 / Capture stream was interrupted")
                    self.wait(policy.frame_size / model.rate)
        finally:
            devices.abort()
            while devices.ring.count:
                raw, timestamp = devices.ring.read(max(1, math.ceil(policy.frame_size * devices.input_rate / model.rate)))
                if origin is None:
                    origin = timestamp
                consume(resampler.resample_chunk(raw))
            if origin is not None:
                consume(resampler.resample_chunk(np.empty(0, dtype=np.float32), last=True), final=True)
                save(gate.flush(), segment_start if segment_start is not None else origin + position / model.rate, final=True)
            self.speaking = False

def concise_error(exc):
    seen = set()
    values = []
    while exc is not None and id(exc) not in seen:
        seen.add(id(exc))
        value = str(exc).strip().replace("\x00", "")
        values.append(type(exc).__name__ + (": " + value if value else ""))
        exc = exc.__cause__ if exc.__cause__ is not None else (None if exc.__suppress_context__ else exc.__context__)
    return " ← ".join(values)

class Engine:
    def __init__(self, state, emit, shutdown=None):
        self.state, self.emit = Path(state), emit
        self.shutdown = shutdown if shutdown is not None else threading.Event()
        self.interrupt = threading.Event()
        self.requests = queue.Queue()
        self.devices = None
        self.session_id = None
        self.language = "中文"
        self.store = None
        self.model = None
        self.last_metrics = 0.0
        self.metrics_period = math.sqrt(os.cpu_count() or 1)
        self.command_lock = threading.Lock()
        self.closed_sessions = set()
        self.cached_samples = {}
        self.resource_thread = None

    def receive(self):
        try:
            while not self.shutdown.is_set():
                line = sys.stdin.readline()
                if not line:
                    break
                try:
                    action = json.loads(line)
                except (ValueError, TypeError):
                    continue
                if not isinstance(action, dict):
                    continue
                command = action.get("action")
                if command not in ("start", "stop", "close", "language"):
                    continue
                with self.command_lock:
                    if command == "language":
                        self.language = "English" if action.get("language") == "English" else "中文"
                        continue
                    if command == "stop":
                        self.closed_sessions.add(str(action.get("id", "")))
                    self.interrupt.set()
                    if command == "close":
                        self.shutdown.set()
                    if self.devices:
                        self.devices.abort()
                    try:
                        self.requests.put_nowait(action)
                    except queue.Full:
                        self.shutdown.set()
        finally:
            self.shutdown.set()
            self.interrupt.set()
            if self.devices:
                self.devices.abort()

    def stats(self, force=False):
        import psutil
        now = time.monotonic()
        if threading.current_thread() is threading.main_thread() and self.store:
            self.cached_samples = self.store.stats()
        if not force and now - self.last_metrics < self.metrics_period:
            return
        self.last_metrics = now
        memory = psutil.virtual_memory()
        disk = shutil.disk_usage(self.state)
        process = psutil.Process()
        values = {"cpu": psutil.cpu_percent(), "ram_used": memory.used, "ram_available": memory.available, "process_ram": process.memory_info().rss,
                  "disk_free": disk.free, "disk_total": disk.total, "samples": self.cached_samples,
                  "capture": {"id": None, "continuous": False, "speech_active": False, "pending": 0}}
        if self.devices and self.devices.capture:
            capture = self.devices.capture
            values["capture"] = {"id": capture.session_id, "continuous": capture.connected, "speech_active": capture.speaking, "pending": max(0, capture.saved - capture.consumed)}
        if self.model and self.model.device.type == "cuda":
            try:
                free, total = self.model.torch.cuda.mem_get_info()
                values.update(gpu_used=total - free, gpu_total=total)
            except RuntimeError:
                pass
        self.emit("metrics", **values)

    def resource_loop(self):
        failure = None
        while not self.shutdown.wait(max(math.sqrt(tick()), min(1.0, self.metrics_period))):
            try:
                self.stats(True)
                if failure:
                    self.emit("notice", key="recovered", component="resources")
                failure = None
            except Exception as exc:
                reason = concise_error(exc)
                if reason != failure:
                    self.emit("notice", key="resource_failure", reason=reason)
                failure = reason

    def check_pipeline(self):
        import numpy as np
        count = self.model.hop * max(4, self.model.layers + 1)
        generator = np.random.default_rng(int(self.model.identity()[:16], 16))
        amplitude = np.finfo(np.float32).eps ** 0.25
        waveform = generator.normal(0.0, amplitude, count).astype(np.float32)
        output = self.model.respond_audio(tr("default_prompt", self.language), [], waveform, self.shutdown, max_samples=count)
        if not output.size or not np.isfinite(output).all():
            raise YuanError("端到端音频链路验证失败 / End-to-end audio pipeline validation failed")
        self.emit("pipeline", verified=True, conversation_verified=False, path="ordered prompt + processed audio → Yuan encoder/decoder → autoregressive waveform",
                  transcription=False, text_to_speech=False, external_model=False, playback=False)

    def conversation(self, action):
        import soundfile as sf
        session_id = str(action.get("id", ""))
        if not session_id or session_id in self.closed_sessions:
            self.emit("ended", id=session_id)
            return
        self.language = "English" if action.get("language") == "English" else "中文"
        prompt = str(action.get("prompt", "")).strip() or tr("default_prompt", self.language)
        self.session_id = session_id
        history = deque()
        turns = 0
        started = time.monotonic()
        capture = None
        try:
            self.store.session(session_id, prompt, self.language)
            self.store.group(session_id, "local")
            self.model.input_budget = max(self.model.hop * 2, self.model.capacity() // 2)
            capture = CaptureSession(self.devices, session_id, self.interrupt, self.emit)
            self.emit("started", id=session_id, mode="experimental" if self.model.accepted else "record_only", model=self.model.active_digest, continuous=False)
            capture.start()
            while not self.shutdown.is_set():
                check(self.interrupt)
                row = capture.next(self.store)
                try:
                    processed, rate = sf.read(str(safe_path(self.store.root, row["audio"])), dtype="float32", always_2d=False)
                    if rate != self.model.rate or processed.ndim != 1 or len(processed) != row["count"] or not self.model.np.isfinite(processed).all():
                        raise YuanError("已保存的输入音频无效 / Stored input audio is invalid")
                    metadata = json.loads(row["metadata"])
                    reply_cancel = ReplyCancel(self.interrupt, capture, int(metadata["revision"]))
                    began = time.monotonic()
                    heard = None
                    output_sample = None
                    latency = None
                    mode = "record_only"
                    playback_started = None
                    try:
                        if not self.model.accepted:
                            self.emit("notice", key="collecting", sample=row["id"])
                        elif reply_cancel.is_set():
                            mode = "superseded"
                        else:
                            mode = "experimental"
                            self.emit("status", key="thinking", id=session_id)
                            output = self.model.respond_audio(prompt, list(history), processed, reply_cancel)
                            latency = time.monotonic() - began
                            check(reply_cancel)
                            playback_started = time.time()
                            heard, interrupted = self.devices.play(output, self.model.output_rate, reply_cancel)
                            if interrupted:
                                mode = "interrupted"
                                self.emit("notice", key="barge_in", sample=row["id"])
                    except Cancelled:
                        mode = "interrupted"
                        if not self.interrupt.is_set():
                            self.emit("notice", key="barge_in", sample=row["id"])
                    except Exception as exc:
                        mode = "failed"
                        self.emit("notice", reason=concise_error(exc), component="reply", input_sample=row["id"])
                        if isinstance(exc, MemoryError) or "out of memory" in str(exc).lower():
                            self.model.capacity_scale /= math.sqrt(2)
                            self.model.input_budget = max(self.model.hop * 2, self.model.capacity() // 2)
                            import gc
                            gc.collect()
                            if self.model.torch.cuda.is_available():
                                self.model.torch.cuda.empty_cache()
                    finally:
                        history.append(("user", processed.copy()))
                        if heard is not None and len(heard):
                            history.append(("assistant", heard.copy()))
                            try:
                                output_sample = self.store.add(session_id, "assistant", heard, self.model.output_rate, "local", generated=True, created=playback_started,
                                                               metadata={"input_sample": row["id"], "interrupted": mode == "interrupted", "model": self.model.active_digest, "submitted_to_device": True})
                            except (OSError, sqlite3.Error, YuanError) as exc:
                                self.emit("notice", key="history_full", reason=concise_error(exc))
                        while sum(len(item[1]) for item in history) > self.model.capacity() // 2 and len(history) > 1:
                            history.popleft()
                        turns += 1
                        pending = self.store.db.execute("SELECT count(*) FROM samples WHERE group_id=? AND role='user' AND rowid>?", (session_id, capture.last_row)).fetchone()[0]
                        self.emit("turn", id=session_id, turns=turns, latency=latency, input_seconds=len(processed) / self.model.rate,
                                  output_seconds=len(heard) / self.model.output_rate if heard is not None else 0.0, elapsed=time.monotonic() - started,
                                  mode=mode, input_sample=row["id"], output_sample=output_sample, model=self.model.active_digest, pending=pending, continuous=capture.connected)
                        if capture.connected and not self.interrupt.is_set():
                            self.emit("status", key="listening", id=session_id)
                        self.stats(True)
                except Cancelled:
                    raise
                except Exception as exc:
                    self.emit("notice", reason=concise_error(exc), component="stored_input", sample=row["id"])
        except Cancelled:
            pass
        except Exception as exc:
            if not self.interrupt.is_set():
                self.emit("notice", reason=concise_error(exc))
        finally:
            if capture is not None:
                capture.stop()
            self.devices.abort()
            try:
                self.store.end_session(session_id)
            except (OSError, sqlite3.Error) as exc:
                self.emit("notice", reason=concise_error(exc))
            self.model.input_budget = None
            history.clear()
            self.session_id = None
            self.emit("ended", id=session_id, turns=turns)
            self.stats(True)

    def run(self):
        import gc
        import psutil
        receiver = threading.Thread(target=self.receive, daemon=True)
        receiver.start()
        model = None
        learner = None
        try:
            from importlib.metadata import version, PackageNotFoundError
            components = {}
            for name in ("torch", "numpy", "sounddevice", "soundfile", "soxr", "psutil"):
                try:
                    components[name] = version(name)
                except PackageNotFoundError:
                    components[name] = None
            self.emit("runtime_profile", python=platform.python_version(), system=platform.system(), machine=platform.machine(), components=components)
            self.store = AudioStore(self.state)
            self.language = self.store.setting("language", "中文")
            settings = read_json(self.state / "settings.json")
            if settings.get("language") in ("中文", "English"):
                self.language = settings["language"]
            self.stats(True)
            self.resource_thread = threading.Thread(target=self.resource_loop, daemon=True)
            self.resource_thread.start()
            self.emit("status", key="loading")
            model = NativeAudio(self.state, self.shutdown, self.emit)
            self.model = model
            self.devices = AudioDevices(model, self.emit)
            self.emit("status", key="checking")
            try:
                self.check_pipeline()
            except RuntimeError as exc:
                if model.device.type == "cpu":
                    raise
                self.emit("notice", key="device_fallback", reason=concise_error(exc))
                model.device = model.torch.device("cpu")
                model.network.to(model.device)
                self.emit("model", device="cpu")
                self.check_pipeline()
            try:
                self.devices.probe()
            except Exception as exc:
                self.emit("notice", key="mic_missing", reason=concise_error(exc))
            learner = AudioLearner(model, self.store, self.emit)
            sources = PublicAudio(self.state, self.store, model, self.emit)
            self.emit("ready", capability="experimental" if model.accepted else "cold_start", conversation_verified=False)
            self.stats(True)
            duration = model.chunk_seconds
            failures = 0
            while not self.shutdown.is_set():
                action = None
                with self.command_lock:
                    try:
                        action = self.requests.get_nowait()
                    except queue.Empty:
                        pass
                    if self.requests.empty() and not self.shutdown.is_set():
                        self.interrupt.clear()
                if action:
                    if action["action"] == "close":
                        break
                    if action["action"] == "start":
                        if self.interrupt.is_set():
                            self.emit("ended", id=str(action.get("id", "")))
                        else:
                            self.conversation(action)
                        continue
                    if action["action"] == "stop":
                        self.closed_sessions.discard(str(action.get("id", "")))
                        self.emit("ended", id=str(action.get("id", "")))
                        continue
                began = time.monotonic()
                try:
                    self.store.set_setting("language", self.language)
                    try:
                        battery = psutil.sensors_battery()
                    except (AttributeError, OSError, NotImplementedError):
                        battery = None
                    worked = False
                    if psutil.virtual_memory().available < model.required_training_memory():
                        self.emit("learning", key="memory_pause", steps=learner.steps, accepted=model.accepted)
                    else:
                        try:
                            worked = learner.step(self.interrupt)
                        except Cancelled:
                            raise
                        except Exception as exc:
                            self.emit("learning", key="paused", steps=learner.steps, accepted=model.accepted, reason=concise_error(exc))
                            if isinstance(exc, MemoryError) or "out of memory" in str(exc).lower():
                                model.capacity_scale /= math.sqrt(2)
                                gc.collect()
                                if model.torch.cuda.is_available():
                                    model.torch.cuda.empty_cache()
                    check(self.interrupt)
                    worked = sources.step(self.interrupt) or worked
                    self.stats(True)
                    measured = max(tick(), time.monotonic() - began)
                    duration = max(tick(), math.sqrt(duration * measured))
                    load = psutil.cpu_percent() / 100
                    delay = max(math.sqrt(model.chunk_seconds * measured), duration) * (1 + load) if worked else max(model.chunk_seconds, duration)
                    if battery and not battery.power_plugged:
                        delay *= 100 / max(1, battery.percent)
                    failures = 0
                    self.interrupt.wait(delay)
                except Cancelled:
                    self.emit("learning", key="learn_yield", steps=learner.steps, accepted=model.accepted)
                except Exception as exc:
                    failures += 1
                    self.emit("learning", key="paused", steps=learner.steps, accepted=model.accepted, reason=concise_error(exc))
                    if isinstance(exc, MemoryError) or "out of memory" in str(exc).lower():
                        model.capacity_scale /= math.sqrt(2)
                    gc.collect()
                    if model.torch.cuda.is_available():
                        model.torch.cuda.empty_cache()
                    self.interrupt.wait(max(model.chunk_seconds, duration, time.monotonic() - began) * math.sqrt(failures))
        except Cancelled:
            pass
        except BaseException as exc:
            self.emit("error", key="failure", reason=concise_error(exc))
        finally:
            self.shutdown.set()
            self.interrupt.set()
            if self.devices:
                self.devices.abort()
            if self.resource_thread:
                self.resource_thread.join(timeout=max(1.0, self.metrics_period))
            if learner is not None:
                try:
                    learner.checkpoint(None)
                except Exception as exc:
                    self.emit("notice", key="checkpoint_failure", component="shutdown_checkpoint", reason=concise_error(exc))
            if self.store:
                try:
                    self.store.close()
                except (OSError, sqlite3.Error) as exc:
                    self.emit("notice", reason=concise_error(exc))
            self.emit("exit")

def engine_entry(state):
    state = Path(state).resolve()
    state.mkdir(parents=True, exist_ok=True)
    for key, value in workspace_environment(state.parent).items():
        os.environ[key] = value
    tempfile.tempdir = os.environ["TMPDIR"]
    os.chdir(state)
    try:
        import certifi
        os.environ.setdefault("SSL_CERT_FILE", certifi.where())
    except ImportError:
        pass
    output = os.fdopen(os.dup(sys.stdout.fileno()), "w", encoding="utf-8", buffering=1)
    events = EventStream(output)
    emit = events.emit
    read_fd, write_fd = os.pipe()
    os.dup2(write_fd, sys.stdout.fileno())
    os.dup2(write_fd, sys.stderr.fileno())
    os.close(write_fd)
    def capture():
        with os.fdopen(read_fd, "r", encoding="utf-8", errors="replace") as stream:
            for line in stream:
                value = line.rstrip("\r\n")
                if value:
                    try:
                        emit("runtime_message", detail=value)
                    except (BrokenPipeError, OSError, ValueError):
                        return
    recorder = threading.Thread(target=capture, daemon=True)
    recorder.start()
    import logging
    logging.basicConfig(level=logging.WARNING)
    try:
        with WorkspaceLease(state / "engine.lock"):
            Engine(state, emit, shutdown=events.cancel).run()
    except (BrokenPipeError, OSError):
        return
    except Exception as exc:
        emit("error", key="failure", reason=concise_error(exc))
    finally:
        for stream in (sys.stdout, sys.stderr):
            try:
                stream.flush()
                os.dup2(output.fileno(), stream.fileno())
            except (OSError, ValueError):
                pass
        recorder.join(timeout=max(1, math.sqrt(os.cpu_count() or 1)))
        events.close()
        output.close()

class ActivityStore:
    def __init__(self, state):
        self.path = database_path(state, "activity.sqlite3")
        self.lock = threading.RLock()
        self.db = sqlite3.connect(str(self.path), check_same_thread=False, timeout=max(1, math.sqrt(os.cpu_count() or 1)))
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.execute("CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY, at REAL NOT NULL, kind TEXT NOT NULL, payload TEXT NOT NULL)")
        self.db.commit()
        self.closed = False

    def add(self, event):
        with self.lock:
            if self.closed:
                return
            payload = json.dumps(event, ensure_ascii=False, allow_nan=False, separators=(",", ":"))
            try:
                self.db.execute("INSERT INTO events(at,kind,payload) VALUES(?,?,?)", (event.get("at", time.time()), event.get("type", ""), payload))
                self.db.commit()
            except sqlite3.Error:
                self.db.rollback()
                raise

    def page(self, before=None, limit=None):
        with self.lock:
            if self.closed:
                return []
            limit = max(1, int(limit or math.isqrt(max(1, self.path.stat().st_size))))
            if before is None:
                rows = self.db.execute("SELECT id,payload FROM events ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
            else:
                rows = self.db.execute("SELECT id,payload FROM events WHERE id<? ORDER BY id DESC LIMIT ?", (before, limit)).fetchall()
            return [(row[0], json.loads(row[1])) for row in reversed(rows)]

    def close(self):
        with self.lock:
            if not self.closed:
                self.db.execute("PRAGMA wal_checkpoint(TRUNCATE)")
                self.db.close()
                self.closed = True


def event_text(event, language, compact=False):
    moment = time.strftime("%H:%M:%S", time.localtime(event.get("at", time.time())))
    kind = event.get("key") or event.get("type", "")
    title = tr(kind, language)
    values = {key: value for key, value in event.items() if key not in ("at", "type", "key", "generation", "_sequence")}
    body = json.dumps(values, ensure_ascii=False, allow_nan=False, indent=None if compact else 2) if values else ""
    return moment + "  " + title + ((" · " if compact else "\n") + body if body else "") + "\n"

class Mailbox:
    def __init__(self):
        self.events = deque()
        self.latest = {}
        self.lock = threading.Lock()
        self.sequence = 0

    def put(self, event):
        with self.lock:
            self.sequence += 1
            event = {**event, "_sequence": self.sequence}
            if event.get("type") in ("progress", "phase", "audio", "metrics", "devices", "model"):
                key = (event.get("generation"), event["type"], event.get("id"))
                if event["type"] in ("audio", "metrics", "devices", "model"):
                    event = {**self.latest.get(key, {}), **event}
                self.latest[key] = event
            else:
                self.events.append(event)

    def drain(self):
        with self.lock:
            events = list(self.events) + list(self.latest.values())
            self.events.clear()
            self.latest.clear()
        return sorted(events, key=lambda event: event["_sequence"])

class EventStream:
    def __init__(self, stream):
        self.stream = stream
        self.mailbox = Mailbox()
        self.wake = threading.Event()
        self.closing = threading.Event()
        self.cancel = threading.Event()
        self.failed = threading.Event()
        self.lock = threading.Lock()
        self.thread = threading.Thread(target=self.run, daemon=True, name="YuanEvents")
        self.thread.start()

    def emit(self, kind, **values):
        with self.lock:
            if self.closing.is_set() or self.failed.is_set():
                return
            self.mailbox.put({"type": kind, "at": time.time(), **values})
            self.wake.set()

    def run(self):
        try:
            while True:
                self.wake.wait()
                self.wake.clear()
                events = self.mailbox.drain()
                if events:
                    payload = "".join(json.dumps(event, ensure_ascii=False, allow_nan=False, separators=(",", ":")) + "\n" for event in events)
                    self.stream.write(payload)
                    self.stream.flush()
                if self.closing.is_set():
                    remaining = self.mailbox.drain()
                    if remaining:
                        self.stream.write("".join(json.dumps(event, ensure_ascii=False, allow_nan=False, separators=(",", ":")) + "\n" for event in remaining))
                        self.stream.flush()
                    break
        except (OSError, ValueError, TypeError):
            self.failed.set()
            self.cancel.set()

    def close(self):
        with self.lock:
            self.closing.set()
            self.wake.set()
        self.thread.join()

class Launcher:
    def __init__(self, workspace, generation, mailbox, lease=None):
        self.workspace, self.generation, self.mailbox = Path(workspace).resolve(), generation, mailbox
        self.cancel = threading.Event()
        self.process = None
        self.lock = threading.RLock()
        self.thread = threading.Thread(target=self.run, daemon=True)
        self.lease = lease
        self.send_lock = threading.Lock()
        self.commands = queue.Queue()
        self.sender = threading.Thread(target=self.send_loop, daemon=True, name="YuanCommands")
        self.activity = ActivityStore(safe_path(self.workspace, STATE_NAME))
        self.phase_at = time.monotonic()
        self.phase_key = "setup"
        self.retry_until = None
        self.activity_error = None
        self.sender.start()
        self.thread.start()

    def emit(self, kind, **values):
        event = {"type": kind, "generation": self.generation, "at": time.time(), **values}
        if kind == "status":
            self.phase_at = time.monotonic()
            self.phase_key = event.get("key", self.phase_key)
            self.retry_until = None
        elif kind == "recovery":
            self.retry_until = time.monotonic() + max(0, float(event.get("seconds", 0)))
        try:
            self.activity.add(event)
            if self.activity_error:
                recovered = {"type": "notice", "generation": self.generation, "at": time.time(), "key": "recording_resumed"}
                self.activity.add(recovered)
                self.mailbox.put(recovered)
                self.activity_error = None
        except (sqlite3.Error, OSError, ValueError) as exc:
            reason = concise_error(exc)
            if reason != self.activity_error:
                self.mailbox.put({"type": "notice", "generation": self.generation, "at": time.time(), "key": "journal_failure", "reason": reason})
            self.activity_error = reason
        self.mailbox.put(event)

    def send(self, action):
        with self.lock:
            process = self.process
        if not process or process.poll() is not None:
            return False
        self.commands.put((process, dict(action)))
        return True

    def send_loop(self):
        while True:
            item = self.commands.get()
            if item is None:
                return
            process, action = item
            with self.lock:
                current = self.process
            if process is not current or process.poll() is not None:
                continue
            try:
                with self.send_lock:
                    process.stdin.write(json.dumps(action, ensure_ascii=False, allow_nan=False) + "\n")
                    process.stdin.flush()
            except (OSError, ValueError, TypeError):
                self.emit("notice", key="command_failed", action=action.get("action"), id=action.get("id"))
                end_process(process)

    def stop(self):
        if self.cancel.is_set():
            return
        self.cancel.set()
        self.send({"action": "close"})
        def terminate():
            with self.lock:
                process = self.process
            if process and process.poll() is None:
                fallback = max(1.0, math.sqrt(os.cpu_count() or 1))
                configuration = read_json(safe_path(self.workspace, STATE_NAME) / "learning" / "model.json")
                try:
                    grace = float(configuration.get("capacity_seconds", fallback))
                    grace = max(fallback, grace) if math.isfinite(grace) and grace > 0 else fallback
                except (ValueError, TypeError, OverflowError):
                    grace = fallback
                try:
                    process.wait(timeout=grace)
                except subprocess.TimeoutExpired:
                    end_process(process)
        threading.Thread(target=terminate, daemon=True, name="YuanShutdown").start()

    def run(self):
        state = safe_path(self.workspace, STATE_NAME)
        failures = 0
        duration = math.sqrt(os.cpu_count() or 1)
        try:
            if self.lease is None:
                self.lease = WorkspaceLease(state / "workspace.lock")
            with WorkspaceLease(state / "engine.lock"):
                pass
            while not self.cancel.is_set():
                started = time.monotonic()
                try:
                    installer = RuntimeInstaller(self.workspace, self.cancel, self.emit)
                    interpreter = installer.ensure()
                    check(self.cancel)
                    self.emit("status", key="loading")
                    process = spawn([str(interpreter), "-B", str(Path(__file__).resolve()), "--engine", str(state)], installer.env,
                                    stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace", bufsize=1)
                    with self.lock:
                        self.process = process
                    if self.cancel.is_set():
                        end_process(process)
                        raise Cancelled()
                    for line in iter(process.stdout.readline, ""):
                        try:
                            event = json.loads(line)
                        except ValueError:
                            self.emit("runtime_message", detail=line.rstrip("\r\n"))
                            continue
                        if isinstance(event, dict) and isinstance(event.get("type"), str):
                            if event["type"] == "ready":
                                failures = 0
                            kind = event.pop("type")
                            self.emit(kind, **event)
                    process.wait()
                    check(self.cancel)
                    failures += 1
                    self.emit("disconnected", returncode=process.returncode)
                except Cancelled:
                    break
                except Exception as exc:
                    failures += 1
                    self.emit("error", key="failure", reason=concise_error(exc))
                finally:
                    with self.lock:
                        process, self.process = self.process, None
                    if process:
                        if process.poll() is None:
                            end_process(process)
                        for stream in (process.stdin, process.stdout):
                            if stream:
                                stream.close()
                if not self.cancel.is_set():
                    duration = max(tick(), math.sqrt(duration * max(tick(), time.monotonic() - started)))
                    self.emit("status", key="retry")
                    delay = duration * math.sqrt(failures + 1)
                    self.emit("recovery", key="backoff", seconds=delay, attempts=failures)
                    self.cancel.wait(delay)
        except Exception as exc:
            self.emit("error", key="failure", reason=concise_error(exc))
        finally:
            self.commands.put(None)
            self.sender.join(timeout=max(tick(), math.sqrt(tick())))
            if self.lease:
                self.lease.close()
            self.emit("launcher_closed")

class YuanApp:
    def __init__(self, root):
        import tkinter as tk
        from tkinter import ttk, font
        self.tk, self.ttk, self.root = tk, ttk, root
        self.mailbox = Mailbox()
        self.launcher = None
        self.workspace = None
        self.generation = 0
        self.ready = False
        self.session_id = None
        self.pending_start = None
        self.session_started = None
        self.ending = False
        self.closing = False
        self.language = "中文"
        self.status_key = "idle"
        self.learning_key = "waiting_data"
        self.network_key = "wait"
        self.reason = ""
        self.notice_key = ""
        self.device_values = {}
        self.model_values = {}
        self.audio_values = {}
        self.learning_values = {}
        self.resource_values = {}
        self.progress_value = {}
        self.phase_values = {}
        self.activity_window = None
        self.recent_activity = deque()
        self.pipeline_verified = False
        self.level = 0.0
        self.phase = 0.0
        self.last_draw = time.monotonic()
        self.last_saved_prompt = None
        self.save_job = None
        self.pending_workspace = None
        self.palette = {"bg": "#090d16", "panel": "#121a28", "field": "#0c1320", "border": "#25334a", "text": "#f0f4ff", "muted": "#a5b4cd",
                        "accent": "#79e7d2", "lavender": "#baacff", "warning": "#ffc891"}
        families = set(font.families(root))
        family = next((name for name in ("Microsoft YaHei UI", "PingFang SC", "Noto Sans CJK SC", "Noto Sans CJK TC", "WenQuanYi Micro Hei", "Arial") if name in families), "TkDefaultFont")
        self.unit = max(8, int(round(font.nametofont("TkDefaultFont").metrics("linespace") / 1.8)))
        self.base = 10
        self.font = font.Font(root=root, family=family, size=self.base)
        self.small_font = font.Font(root=root, family=family, size=self.base - 1)
        self.heading_font = font.Font(root=root, family=family, size=self.base + 10, weight="bold")
        self.brand_font = font.Font(root=root, family=family, size=self.base + 16, weight="bold")
        self.bold_font = font.Font(root=root, family=family, size=self.base, weight="bold")
        self.root.title(APP_NAME)
        self.root.configure(bg=self.palette["bg"])
        self.root.option_add("*Font", self.font)
        screen_width, screen_height = root.winfo_screenwidth(), root.winfo_screenheight()
        width = min(screen_width, max(680, int(screen_width * .88)))
        height = min(screen_height, max(500, screen_height - self.font.metrics("linespace") * 2))
        self.root.geometry(f"{width}x{height}+{max(0, (screen_width-width)//2)}+{max(0, (screen_height-height)//2)}")
        self.root.minsize(min(420, screen_width), min(380, screen_height))
        self.style = ttk.Style(root)
        if "clam" in self.style.theme_names():
            self.style.theme_use("clam")
        self.style.configure("Yuan.Horizontal.TProgressbar", troughcolor=self.palette["field"], background=self.palette["accent"], bordercolor=self.palette["field"], lightcolor=self.palette["accent"], darkcolor=self.palette["accent"], thickness=3)
        self.style.configure("Yuan.Vertical.TScrollbar", background=self.palette["border"], troughcolor=self.palette["bg"], bordercolor=self.palette["bg"], arrowcolor=self.palette["muted"], width=9)
        self.root.grid_rowconfigure(0, weight=1)
        self.root.grid_columnconfigure(0, weight=1)
        self.viewport = tk.Canvas(root, bg=self.palette["bg"], highlightthickness=0, bd=0)
        self.viewport.grid(row=0, column=0, sticky="nsew")
        self.scrollbar = ttk.Scrollbar(root, orient="vertical", style="Yuan.Vertical.TScrollbar", command=self.viewport.yview)
        self.viewport.configure(yscrollcommand=self.scrollbar.set)
        self.body = tk.Frame(self.viewport, bg=self.palette["bg"], padx=self.unit*2, pady=self.unit)
        self.body_window = self.viewport.create_window(0, 0, window=self.body, anchor="nw")
        self.body.grid_columnconfigure(0, weight=1)
        self.viewport.bind("<Configure>", self.resize)
        self.body.bind("<Configure>", self.measure)
        self.root.bind_all("<MouseWheel>", self.wheel)
        self.root.bind_all("<Button-4>", self.wheel)
        self.root.bind_all("<Button-5>", self.wheel)
        self.bound = []
        self.build_header()
        self.build_controls()
        self.build_hero()
        self.build_cards()
        self.build_footer()
        self.build_activity()
        self.root.protocol("WM_DELETE_WINDOW", self.close)
        self.root.bind("<Control-Return>", lambda event: self.toggle())
        self.root.report_callback_exception = self.callback_error
        self.localize()
        self.refresh()
        self.root.after(max(1, int(math.sqrt(tick()) * 1000)), self.pump)
        self.root.after(max(1, int(tick() * 1000)), self.animate)

    def label(self, parent, text="", key=None, **options):
        defaults = dict(bg=parent.cget("bg"), fg=self.palette["text"], anchor="w", justify="left", bd=0, font=self.font)
        defaults.update(options)
        widget = self.tk.Label(parent, text=text if key is None else tr(key, self.language), **defaults)
        if key:
            self.bound.append((widget, key))
        return widget

    def button(self, parent, command, text="", key=None, primary=False, **options):
        defaults = dict(bg=self.palette["accent"] if primary else self.palette["panel"], fg=self.palette["bg"] if primary else self.palette["text"],
                        activebackground=self.palette["lavender"] if primary else self.palette["border"], activeforeground=self.palette["bg"] if primary else self.palette["text"],
                        disabledforeground=self.palette["muted"], relief="flat", bd=0, padx=self.unit*2, pady=self.unit, cursor="hand2", font=self.bold_font,
                        highlightthickness=1, highlightbackground=self.palette["border"], highlightcolor=self.palette["accent"], takefocus=True)
        defaults.update(options)
        widget = self.tk.Button(parent, text=text if key is None else tr(key, self.language), command=command, **defaults)
        if key:
            self.bound.append((widget, key))
        return widget

    def build_header(self):
        top = self.tk.Frame(self.body, bg=self.palette["bg"])
        top.grid(row=0, column=0, sticky="ew", pady=(0, self.unit))
        top.grid_columnconfigure(1, weight=1)
        brand = self.label(top, text="Y U A N", font=self.brand_font)
        native = self.label(top, text="NATIVE AUDIO", fg=self.palette["accent"], font=self.small_font)
        subtitle = self.label(top, key="subtitle", fg=self.palette["muted"], font=self.small_font)
        self.language_button = self.button(top, self.switch_language, text="中文  /  EN", padx=self.unit, pady=max(3, self.unit//2))
        def layout(event):
            available = event.width - brand.winfo_reqwidth() - self.language_button.winfo_reqwidth() - self.unit*4
            compact = available < self.small_font.measure("Prompt + processed audio")
            brand.grid(row=0, column=0, rowspan=1 if compact else 2, sticky="w")
            self.language_button.grid(row=0, column=2, rowspan=1 if compact else 2, sticky="e")
            native.grid(row=1 if compact else 0, column=0 if compact else 1, columnspan=3 if compact else 1, sticky="w",
                        padx=0 if compact else self.unit*2, pady=(self.unit//2 if compact else 0, 0))
            subtitle.grid(row=2 if compact else 1, column=0 if compact else 1, columnspan=3 if compact else 1, sticky="ew",
                          padx=0 if compact else self.unit*2)
            subtitle.configure(wraplength=max(self.unit, event.width if compact else available))
        top.bind("<Configure>", layout)
        layout(types.SimpleNamespace(width=self.root.winfo_width()))

    def build_controls(self):
        panel = self.tk.Frame(self.body, bg=self.palette["panel"], padx=self.unit, pady=self.unit, highlightthickness=1, highlightbackground=self.palette["border"])
        panel.grid(row=1, column=0, sticky="ew")
        panel.grid_columnconfigure(1, weight=1)
        self.label(panel, key="folder", fg=self.palette["muted"], font=self.small_font).grid(row=0, column=0, sticky="w", padx=(0, self.unit))
        self.folder_var = self.tk.StringVar(value=tr("empty_folder", self.language))
        self.folder_entry = self.tk.Entry(panel, textvariable=self.folder_var, state="readonly", readonlybackground=self.palette["panel"], fg=self.palette["text"], relief="flat", bd=0, highlightthickness=0)
        self.folder_entry.grid(row=0, column=1, sticky="ew", padx=self.unit)
        self.folder_entry.configure(width=1)
        self.choose_button = self.button(panel, self.choose, key="choose", pady=max(3, self.unit//2))
        self.choose_button.grid(row=0, column=2, sticky="e")
        self.label(panel, key="prompt", fg=self.palette["muted"], font=self.small_font).grid(row=1, column=0, sticky="nw", pady=(self.unit, 0))
        self.prompt = self.tk.Text(panel, height=2, width=1, wrap="word", undo=True, maxundo=max(1, os.cpu_count() or 1), bg=self.palette["field"], fg=self.palette["text"],
                                   insertbackground=self.palette["accent"], selectbackground=self.palette["border"], relief="flat", bd=0, padx=self.unit, pady=self.unit//2,
                                   highlightthickness=1, highlightbackground=self.palette["border"], highlightcolor=self.palette["accent"])
        self.prompt.grid(row=1, column=1, columnspan=2, sticky="ew", padx=(self.unit, 0), pady=(self.unit, 0))
        self.prompt.insert("1.0", tr("default_prompt", self.language))
        self.prompt.bind("<<Modified>>", self.prompt_changed)
        self.prompt.bind("<Tab>", lambda event: self.focus_next(event, False))
        self.prompt.bind("<Shift-Tab>", lambda event: self.focus_next(event, True))
        self.prompt.edit_modified(False)

    def build_hero(self):
        self.hero = self.tk.Frame(self.body, bg=self.palette["bg"], pady=self.unit)
        self.hero.grid(row=2, column=0, sticky="ew")
        self.hero.grid_columnconfigure(1, weight=1)
        self.orb = self.tk.Canvas(self.hero, width=self.unit*7, height=self.unit*7, bg=self.palette["bg"], highlightthickness=0)
        self.orb.grid(row=0, column=0, rowspan=2, sticky="w", padx=(0, self.unit))
        self.status_label = self.label(self.hero, font=self.heading_font)
        self.status_label.grid(row=0, column=1, sticky="sw")
        self.status_detail = self.label(self.hero, key="full_duplex", fg=self.palette["muted"], font=self.small_font)
        self.status_detail.grid(row=1, column=1, sticky="new", pady=(self.unit//2, 0))
        self.action = self.button(self.hero, self.toggle, key="start", primary=True, padx=self.unit*3, pady=self.unit*2)
        self.action.grid(row=0, column=2, rowspan=2, sticky="e", padx=(self.unit, 0))
        def layout(event):
            available = event.width - self.orb.winfo_reqwidth() - self.action.winfo_reqwidth() - self.unit*2
            compact = available < self.heading_font.measure(tr("ended", self.language))
            self.action.grid_configure(row=2 if compact else 0, column=0 if compact else 2, columnspan=3 if compact else 1,
                                       rowspan=1 if compact else 2, sticky="ew" if compact else "e", padx=0 if compact else (self.unit, 0), pady=(self.unit, 0) if compact else 0)
            for widget in (self.status_label, self.status_detail):
                widget.grid_configure(columnspan=2 if compact else 1)
                widget.configure(wraplength=max(self.unit, event.width-self.orb.winfo_reqwidth()-self.unit if compact else available))
        self.hero.bind("<Configure>", layout)
        progress_frame = self.tk.Frame(self.body, bg=self.palette["bg"])
        progress_frame.grid(row=3, column=0, sticky="ew", pady=(0, self.unit))
        progress_frame.grid_columnconfigure(0, weight=1)
        track = self.tk.Frame(progress_frame, bg=self.palette["bg"], height=max(2, self.unit//3))
        track.grid(row=0, column=0, sticky="ew")
        track.pack_propagate(False)
        self.progress = self.ttk.Progressbar(track, style="Yuan.Horizontal.TProgressbar", maximum=1.0)
        self.progress.pack(fill="both", expand=True)
        self.progress_label = self.label(progress_frame, text="", fg=self.palette["muted"], font=self.small_font)
        self.progress_label.grid(row=1, column=0, sticky="ew", pady=(self.unit//2, 0))

    def build_cards(self):
        self.cards_frame = self.tk.Frame(self.body, bg=self.palette["bg"])
        self.cards_frame.grid(row=4, column=0, sticky="nsew")
        self.cards = {}
        self.card_rows = {}
        self.card_columns = 0
        for key in ("devices", "model", "audio", "learning", "storage", "resources"):
            frame = self.tk.Frame(self.cards_frame, bg=self.palette["panel"], highlightthickness=1, highlightbackground=self.palette["border"], padx=self.unit, pady=self.unit)
            frame.grid_columnconfigure(0, weight=1)
            self.label(frame, key=key, fg=self.palette["accent"] if key in ("model", "learning") else self.palette["lavender"], font=self.bold_font).grid(row=0, column=0, sticky="w", pady=(0, self.unit//2))
            rows = []
            for index in range(4):
                widget = self.label(frame, text="—", font=self.small_font, fg=self.palette["text"] if index == 0 else self.palette["muted"])
                widget.grid(row=index+1, column=0, sticky="ew", pady=1)
                rows.append(widget)
            frame.bind("<Configure>", lambda event, labels=rows: [label.configure(wraplength=max(self.unit*4, event.width-self.unit*2)) for label in labels])
            self.cards[key] = frame
            self.card_rows[key] = rows
        self.layout_cards(3)

    def build_footer(self):
        bottom = self.tk.Frame(self.body, bg=self.palette["bg"])
        bottom.grid(row=5, column=0, sticky="ew", pady=(self.unit, 0))
        bottom.grid_columnconfigure(0, weight=1)
        self.notice = self.label(bottom, fg=self.palette["warning"], font=self.small_font)
        self.notice.grid(row=0, column=0, sticky="ew", pady=(0, self.unit//2))
        self.privacy = self.label(bottom, key="privacy", fg=self.palette["muted"], font=self.small_font)
        self.privacy.grid(row=1, column=0, sticky="ew")
        self.metric_note = self.label(bottom, key="metrics_note", fg=self.palette["muted"], font=self.small_font)
        self.metric_note.grid(row=2, column=0, sticky="ew", pady=(self.unit//2, 0))
        for widget in (self.notice, self.privacy, self.metric_note):
            widget.bind("<Configure>", lambda event, target=widget: target.configure(wraplength=max(1, event.width)))
        self.dock = self.tk.Frame(self.root, bg=self.palette["panel"], padx=self.unit, pady=self.unit//2)
        self.dock.grid_columnconfigure(0, weight=1)
        self.dock_status = self.label(self.dock, fg=self.palette["text"])
        self.dock_status.grid(row=0, column=0, sticky="w")
        self.dock_action = self.button(self.dock, self.toggle, key="start", primary=True, pady=self.unit//2)
        self.dock_action.grid(row=0, column=1, sticky="e")
        self.dock.bind("<Configure>", lambda event: self.dock_status.configure(wraplength=max(self.unit, event.width-self.dock_action.winfo_reqwidth()-self.unit*3)))

    def build_activity(self):
        panel = self.tk.Frame(self.body, bg=self.palette["panel"], padx=self.unit, pady=self.unit)
        panel.grid(row=6, column=0, sticky="ew", pady=(self.unit, 0))
        panel.grid_columnconfigure(0, weight=1)
        self.label(panel, key="activity", fg=self.palette["accent"], font=self.bold_font).grid(row=0, column=0, sticky="w")
        self.button(panel, self.show_activity, key="all_activity", pady=self.unit//2).grid(row=0, column=1, sticky="e")
        self.activity_text = self.tk.Text(panel, height=4, width=1, wrap="word", bg=self.palette["field"], fg=self.palette["muted"],
                                          relief="flat", bd=0, font=self.small_font, padx=self.unit, pady=self.unit, state="disabled")
        self.activity_text.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(self.unit, 0))

    def record_activity(self, event):
        if event.get("type") in ("audio", "metrics", "progress", "phase", "devices"):
            return
        self.recent_activity.append(event)
        limit = max(1, self.root.winfo_screenheight() // max(1, self.small_font.metrics("linespace")))
        while len(self.recent_activity) > limit:
            self.recent_activity.popleft()
        self.render_activity()

    def render_activity(self):
        text = self.activity_text
        text.configure(state="normal")
        text.delete("1.0", "end")
        for event in self.recent_activity:
            text.insert("end", event_text(event, self.language, compact=True))
        text.see("end")
        text.configure(state="disabled")

    def show_activity(self):
        if not self.launcher:
            return
        if self.activity_window and self.activity_window.winfo_exists():
            self.activity_window.lift()
            return
        from tkinter import scrolledtext
        window = self.tk.Toplevel(self.root)
        self.activity_window = window
        window.title(tr("all_activity", self.language))
        window.configure(bg=self.palette["bg"])
        window.geometry(f"{max(1, self.root.winfo_width())}x{max(1, self.root.winfo_height())}")
        bar = self.tk.Frame(window, bg=self.palette["panel"])
        bar.pack(fill="x")
        text = scrolledtext.ScrolledText(window, wrap="word", font=self.small_font, bg=self.palette["field"], fg=self.palette["text"],
                                         insertbackground=self.palette["accent"], relief="flat")
        text.pack(fill="both", expand=True)
        position = {"before": None, "trail": [], "first": None, "live": True, "last": None}
        store = self.launcher.activity
        def render():
            if not window.winfo_exists() or store.closed:
                return
            limit = max(1, window.winfo_height() // max(1, self.small_font.metrics("linespace")))
            try:
                rows = store.page(position["before"], limit)
            except (sqlite3.Error, OSError) as exc:
                rows = [(0, {"type": "error", "reason": concise_error(exc)})]
            marker = (rows[-1][0] if rows else None, position["before"], self.language)
            if marker != position["last"]:
                position["first"] = rows[0][0] if rows else None
                position["last"] = marker
                text.configure(state="normal")
                text.delete("1.0", "end")
                text.insert("1.0", "\n".join(event_text(event, self.language) for _, event in rows))
                text.configure(state="disabled")
                if position["live"]:
                    text.see("end")
            self.root.after(max(1, int(math.sqrt(tick()) * 1000)), render)
        def earlier():
            if position["first"] is not None:
                position["trail"].append(position["before"])
                position["before"] = position["first"]
                position["live"] = False
        def later():
            position["before"] = position["trail"].pop() if position["trail"] else None
            position["live"] = position["before"] is None
        def live():
            position.update(before=None, trail=[], live=True, last=None)
        for key, command in (("older", earlier), ("newer", later), ("live", live)):
            self.button(bar, command, text=tr(key, self.language), pady=self.unit//2).pack(side="left", padx=self.unit//2, pady=self.unit//2)
        text.bind("<MouseWheel>", lambda event: position.update(live=False))
        render()

    def layout_cards(self, columns):
        if columns == self.card_columns:
            return
        for column in range(3):
            self.cards_frame.grid_columnconfigure(column, weight=1 if column < columns else 0, uniform="cards" if column < columns else "")
        for index, frame in enumerate(self.cards.values()):
            frame.grid(row=index//columns, column=index%columns, sticky="nsew", padx=(0 if index%columns == 0 else self.unit//2, 0 if index%columns == columns-1 else self.unit//2), pady=self.unit//2)
        self.card_columns = columns

    def resize(self, event):
        self.viewport.itemconfigure(self.body_window, width=event.width)
        self.layout_cards(3 if event.width >= self.font.measure("M") * 105 else 2 if event.width >= self.font.measure("M") * 70 else 1)
        self.root.after_idle(self.measure)

    def measure(self, event=None):
        self.viewport.configure(scrollregion=self.viewport.bbox("all"))
        needs_scroll = self.body.winfo_reqheight() > self.root.winfo_height()
        if needs_scroll:
            self.scrollbar.grid(row=0, column=1, sticky="ns")
            self.dock.grid(row=1, column=0, columnspan=2, sticky="ew")
        else:
            self.scrollbar.grid_remove()
            self.dock.grid_remove()
            self.viewport.yview_moveto(0)

    def wheel(self, event):
        if event.widget is self.prompt or event.widget is self.activity_text or event.widget.winfo_toplevel() is not self.root:
            return
        if self.body.winfo_reqheight() <= self.viewport.winfo_height():
            return
        delta = -1 if getattr(event, "num", None) == 4 or getattr(event, "delta", 0) > 0 else 1
        self.viewport.yview_scroll(delta, "units")

    def focus_next(self, event, reverse):
        (event.widget.tk_focusPrev() if reverse else event.widget.tk_focusNext()).focus_set()
        return "break"

    def localize(self):
        for widget, key in self.bound:
            widget.configure(text=tr(key, self.language))
        if self.workspace is None:
            self.folder_var.set(tr("empty_folder", self.language))
        self.language_button.configure(text="中文  /  EN" if self.language == "中文" else "EN  /  中文")
        self.render_activity()
        self.refresh()

    def switch_language(self):
        old_default = tr("default_prompt", self.language)
        current = self.prompt.get("1.0", "end-1c")
        self.language = "English" if self.language == "中文" else "中文"
        if not self.session_id and current == old_default:
            self.prompt.delete("1.0", "end")
            self.prompt.insert("1.0", tr("default_prompt", self.language))
        if self.launcher:
            self.launcher.send({"action": "language", "language": self.language})
        self.save_settings()
        self.localize()

    def prompt_changed(self, event=None):
        if self.prompt.edit_modified():
            self.prompt.edit_modified(False)
            if self.save_job:
                self.root.after_cancel(self.save_job)
            self.save_job = self.root.after(max(1, int(math.sqrt(tick()) * 1000)), self.save_settings)

    def save_settings(self):
        self.save_job = None
        if self.workspace is None:
            return
        payload = {"prompt": self.prompt.get("1.0", "end-1c"), "language": self.language}
        if payload == self.last_saved_prompt:
            return
        try:
            atomic_json(safe_path(self.workspace, STATE_NAME) / "settings.json", payload)
            self.last_saved_prompt = payload
        except (OSError, ValueError, YuanError) as exc:
            self.reason = concise_error(exc)
            self.refresh()

    def choose(self):
        from tkinter import filedialog
        if self.session_id or self.closing:
            return
        selected = filedialog.askdirectory(parent=self.root, title=tr("choose", self.language), mustexist=True, initialdir=str(self.workspace) if self.workspace else None)
        if not selected:
            return
        selected = Path(selected).resolve()
        if selected == self.workspace and self.launcher and self.launcher.thread.is_alive():
            return
        self.pending_workspace = selected
        self.ready = False
        if self.launcher and self.launcher.thread.is_alive():
            self.status_key = "closed"
            self.launcher.stop()
            self.choose_button.configure(state="disabled")
        else:
            self.open_workspace(selected)
        self.refresh()

    def open_workspace(self, workspace):
        self.pending_workspace = None
        try:
            state = safe_path(workspace, STATE_NAME)
            state.mkdir(parents=True, exist_ok=True)
            fd, test = tempfile.mkstemp(dir=state)
            os.close(fd)
            os.unlink(test)
            lease = WorkspaceLease(state / "workspace.lock")
        except (OSError, YuanError) as exc:
            self.reason = concise_error(exc)
            self.status_key = "failure"
            self.refresh()
            return
        if self.launcher and not self.launcher.thread.is_alive():
            self.launcher.activity.close()
        if self.activity_window and self.activity_window.winfo_exists():
            self.activity_window.destroy()
        self.workspace = workspace
        self.folder_var.set(str(workspace))
        self.last_saved_prompt = None
        settings = read_json(state / "settings.json")
        if settings.get("language") in ("中文", "English"):
            self.language = settings["language"]
        if isinstance(settings.get("prompt"), str):
            self.prompt.configure(state="normal")
            self.prompt.delete("1.0", "end")
            self.prompt.insert("1.0", settings["prompt"])
            self.prompt.edit_modified(False)
        self.reason = ""
        self.notice_key = ""
        self.model_values, self.device_values, self.learning_values, self.resource_values, self.audio_values, self.progress_value = {}, {}, {}, {}, {}, {}
        self.pipeline_verified = False
        self.phase_values = {}
        self.learning_key = "waiting_data"
        self.network_key = "wait"
        self.recent_activity.clear()
        self.activity_text.configure(state="normal")
        self.activity_text.delete("1.0", "end")
        self.activity_text.configure(state="disabled")
        self.ready = False
        self.generation += 1
        self.status_key = "setup"
        self.save_settings()
        try:
            self.launcher = Launcher(workspace, self.generation, self.mailbox, lease=lease)
        except Exception as exc:
            lease.close()
            self.launcher = None
            self.status_key = "failure"
            self.reason = concise_error(exc)
        self.choose_button.configure(state="normal")
        self.localize()

    def toggle(self):
        from tkinter import messagebox
        if self.closing or self.ending:
            return
        if self.session_id:
            if not messagebox.askyesno(tr("confirm_title", self.language), tr("confirm_stop", self.language), parent=self.root):
                return
            self.ending = True
            self.status_key = "ending"
            self.level = 0.0
            if self.pending_start is not None:
                self.pending_start = None
                self.finish_session()
            elif not self.launcher or not self.launcher.send({"action": "stop", "id": self.session_id}):
                self.finish_session()
        elif self.workspace and self.launcher and self.launcher.thread.is_alive():
            value = self.prompt.get("1.0", "end-1c").strip()
            if not value:
                value = tr("default_prompt", self.language)
                self.prompt.insert("1.0", value)
                self.notice_key = "no_prompt"
            self.save_settings()
            self.session_id = uuid.uuid4().hex
            action = {"action": "start", "id": self.session_id, "prompt": value, "language": self.language}
            self.pending_start = action
            self.status_key = "queued"
            self.ending = False
            self.audio_values = {"turns": 0}
            self.reason = ""
            if self.ready and self.launcher.send(action):
                self.pending_start = None
        self.refresh()

    def finish_session(self):
        if self.session_started:
            self.audio_values["elapsed"] = time.monotonic() - self.session_started
        self.session_id = None
        self.pending_start = None
        self.session_started = None
        self.ending = False
        self.status_key = "ended"
        self.phase_values = {}
        self.device_values["continuous_active"] = False
        self.audio_values.update(continuous=False, speech_active=False, recorded=0.0)
        self.level = 0.0

    def close(self):
        from tkinter import messagebox
        if self.closing:
            return
        if self.session_id and not messagebox.askyesno(tr("confirm_title", self.language), tr("confirm_close", self.language), parent=self.root):
            return
        self.closing = True
        self.ready = False
        self.save_settings()
        self.status_key = "closed"
        if self.launcher and self.launcher.thread.is_alive():
            self.launcher.stop()
        else:
            if self.launcher:
                self.launcher.activity.close()
            self.destroy()
            return
        self.refresh()

    def destroy(self):
        self.progress.stop()
        for identifier in self.root.tk.call("after", "info"):
            self.root.tk.call("after", "cancel", identifier)
        self.root.destroy()

    def callback_error(self, kind, value, traceback):
        self.reason = concise_error(value)
        try:
            self.refresh()
        except Exception:
            pass

    def handle(self, event):
        kind = event.get("type")
        self.record_activity(event)
        if kind in ("status", "started", "ended", "audio", "turn") and event.get("id") is not None and event["id"] != self.session_id:
            return
        if kind == "status":
            if not self.ending and not self.closing and self.pending_start is None:
                self.status_key = event.get("key", self.status_key)
        elif kind == "progress":
            self.progress_value = event
        elif kind == "phase":
            self.phase_values = event
        elif kind == "ready":
            if self.closing:
                return
            self.model_values["capability"] = event.get("capability", "cold_start")
            self.ready = True
            self.status_key = "ready"
            self.reason = ""
            self.progress_value = {}
            self.phase_values = {}
            if self.pending_start and self.launcher and self.launcher.send(self.pending_start):
                self.pending_start = None
        elif kind == "pipeline":
            self.pipeline_verified = bool(event.get("verified"))
        elif kind == "started":
            if event.get("id") != self.session_id:
                return
            self.learning_key = "learn_yield"
            self.phase_values = {}
            self.session_started = time.monotonic()
            self.device_values["continuous_active"] = bool(event.get("continuous"))
            if not self.ending and not self.closing:
                self.status_key = "listening" if event.get("continuous") else "connecting"
        elif kind == "ended":
            if event.get("id") == self.session_id:
                self.finish_session()
        elif kind == "devices":
            self.device_values.update(event)
        elif kind == "model":
            self.model_values.update(event)
        elif kind in ("audio", "turn"):
            if kind == "turn" and event.get("id") != self.session_id:
                return
            self.audio_values.update(event)
            if kind == "turn":
                self.phase_values = {}
            if event.get("continuous") is not None:
                self.device_values["continuous_active"] = bool(event["continuous"])
            if not self.ending:
                self.level = max(0.0, min(1.0, float(event.get("level", 0.0))))
        elif kind == "learning":
            self.learning_values.update(event)
            self.learning_key = event.get("key", self.learning_key)
            if self.phase_values.get("key") in ("validating", "checkpointing") and self.learning_key not in ("validating",):
                self.phase_values = {}
            self.model_values["capability"] = "experimental" if event.get("accepted", self.model_values.get("accepted", 0)) else "cold_start"
            self.model_values["accepted"] = event.get("accepted", self.model_values.get("accepted", 0))
            if event.get("key") == "promoted" and self.notice_key == "collecting":
                self.notice_key = ""
            if event.get("reason"):
                self.reason = event["reason"]
        elif kind == "checkpoint_saved":
            if self.phase_values.get("key") == "checkpointing":
                self.phase_values = {}
        elif kind == "network":
            self.network_key = event.get("key", self.network_key)
            if self.network_key == "available" and self.phase_values.get("key") == "network":
                self.phase_values = {}
            if event.get("reason"):
                self.reason = event["reason"]
        elif kind == "metrics":
            self.resource_values.update(event)
            capture = event.get("capture")
            if isinstance(capture, dict) and capture.get("id") == self.session_id:
                self.audio_values.update(capture)
                self.device_values["continuous_active"] = bool(capture.get("continuous"))
        elif kind in ("notice", "error"):
            self.notice_key = event.get("key", "")
            self.reason = event.get("reason", self.reason)
            if kind == "error":
                self.ready = False
                self.status_key = "failure"
        elif kind in ("exit", "disconnected"):
            self.ready = False
            self.pipeline_verified = False
            self.device_values["continuous_active"] = False
            self.audio_values.update(continuous=False, speech_active=False, level=0.0)
            self.level = 0.0
            self.phase_values = {}
            if self.session_id and self.pending_start is None:
                self.finish_session()
            if not self.closing:
                self.status_key = "retry"
        elif kind == "launcher_closed":
            if self.closing:
                if self.launcher:
                    self.launcher.activity.close()
                self.destroy()
                return
            if self.pending_workspace:
                if self.launcher and self.launcher.thread.is_alive():
                    self.root.after(max(1, int(math.sqrt(tick()) * 1000)), lambda: self.handle({"type": "launcher_closed"}))
                    return
                self.open_workspace(self.pending_workspace)
            self.choose_button.configure(state="normal")

    def card(self, key, lines):
        for widget, text in zip(self.card_rows[key], lines):
            widget.configure(text=str(text))

    def refresh(self):
        language = self.language
        translate = lambda key: tr(key, language)
        status = translate(self.status_key) if self.workspace else translate("title")
        self.status_label.configure(text=status)
        self.dock_status.configure(text=status)
        self.status_detail.configure(text=translate(self.model_values.get("capability", "cold_start")) if self.ready else translate("empty_folder") if self.workspace is None else translate("subtitle"),
                                     fg=self.palette["warning"] if self.ready else self.palette["muted"])
        button_key = "ending" if self.ending else "stop" if self.session_id else "start"
        enabled = not self.closing and not self.ending and bool(self.session_id or (self.workspace and self.launcher and self.launcher.thread.is_alive()))
        for button in (self.action, self.dock_action):
            button.configure(text=translate(button_key), state="normal" if enabled else "disabled", bg=(self.palette["warning"] if self.session_id else self.palette["accent"]) if enabled else self.palette["border"])
        self.prompt.configure(state="disabled" if self.session_id or self.closing else "normal")
        self.choose_button.configure(state="disabled" if self.session_id or self.closing or self.pending_workspace else "normal")
        devices = self.device_values
        self.card("devices", [translate("input") + " · " + str(devices.get("input", "—")), translate("output") + " · " + str(devices.get("output", "—")),
                              f"{devices.get('input_rate', '—')} Hz → {devices.get('output_rate', '—')} Hz",
                              ("● " if devices.get("continuous_active") and self.session_id else "○ ") + translate("full_duplex")])
        model = self.model_values
        self.card("model", [model.get("name", "Yuan Native Audio"), f"{model.get('device', '—')} · {model.get('dtype', '—')} · {model.get('size', '—')}",
                            model.get("architecture", "prompt + audio → audio"),
                            ("✓ " + translate("pipeline_ok")) if self.pipeline_verified else translate("wait") + " · audio → audio"])
        audio = self.audio_values
        elapsed = time.monotonic() - self.session_started if self.session_started else audio.get("elapsed", 0.0)
        latency = audio.get("latency")
        self.card("audio", [f"{audio.get('turns', 0)} {translate('turns')} · {int(elapsed)//60:02}:{int(elapsed)%60:02}",
                            f"{translate('input')} {float(audio.get('input_seconds', audio.get('recorded', 0))):.1f}s · {translate('output')} {float(audio.get('output_seconds', 0)):.1f}s",
                            ("响应 " if language == "中文" else "Response ") + (f"{latency:.2f}s" if latency is not None else "—"),
                            f"{translate('input_faults')} {audio.get('input_faults', 0)} · {translate('output_faults')} {audio.get('output_faults', 0)} · {translate('pending')} {audio.get('pending', 0)}"])
        learning = self.learning_values
        before, after = learning.get("before"), learning.get("after")
        guard_before, guard_after = learning.get("guard_before"), learning.get("guard_after")
        self.card("learning", [translate(self.learning_key), f"{translate('steps')} {learning.get('steps', 0)} · {translate('accepted')} {learning.get('accepted', 0)}",
                               ("验证音频损失 " if language == "中文" else "Validation audio loss ") + (f"{before:.5f} → {after:.5f}" if before is not None and after is not None else "—"),
                               ("保护集音频损失 " if language == "中文" else "Guard audio loss ") + (f"{guard_before:.5f} → {guard_after:.5f}" if guard_before is not None and guard_after is not None else "—")])
        resources = self.resource_values
        samples = resources.get("samples", {})
        local, public = samples.get("local", {}), samples.get("public", {})
        self.card("storage", [f"{translate('local')} {local.get('count', 0)} · {float(local.get('seconds', 0))/60:.1f} min",
                              f"{translate('public')} {public.get('count', 0)} · {float(public.get('seconds', 0))/60:.1f} min",
                              translate(self.network_key), ("可学习 " if language == "中文" else "Learnable ") + str(local.get("learnable", 0) + public.get("learnable", 0)) + " · " + translate("excluded") + " " + str(local.get("excluded", 0) + public.get("excluded", 0))])
        self.card("resources", [f"CPU {resources.get('cpu', 0):.1f}% · Yuan {human_bytes(resources.get('process_ram', 0))}",
                                "RAM " + translate("available") + " " + human_bytes(resources.get("ram_available", 0)),
                                "GPU " + human_bytes(resources["gpu_used"]) + " / " + human_bytes(resources["gpu_total"]) if "gpu_used" in resources else "GPU —",
                                "Disk " + human_bytes(resources.get("disk_free", 0)) + " / " + human_bytes(resources.get("disk_total", 0))] if resources else ["—"] * len(self.card_rows["resources"]))
        progress = self.phase_values if self.phase_values.get("total") else self.progress_value
        total, current = progress.get("total"), progress.get("current", 0)
        if total:
            self.progress.stop()
            self.progress.configure(mode="determinate", value=max(0, min(1, current/total)))
            suffix = f" · {human_bytes(current)} / {human_bytes(total)}" if progress.get("unit", "bytes") == "bytes" else f" · {current} / {total}"
        else:
            suffix = ""
            if self.workspace and not self.ready and not self.closing:
                if self.progress.cget("mode") != "indeterminate":
                    self.progress.configure(mode="indeterminate")
                    self.progress.start(max(1, int(math.sqrt(tick()) * 1000)))
            else:
                self.progress.stop()
                self.progress.configure(mode="determinate", value=1.0 if self.ready else 0.0)
        detail = str(progress.get("detail", ""))
        if self.phase_values and (self.ready or self.status_key in ("checking", "loading")):
            phase = self.phase_values
            detail = translate(phase.get("key", "wait"))
            if "current" in phase:
                detail += f" · {phase['current']} / {phase.get('total', '—')} {phase.get('unit', '')}"
            suffix = ""
        if self.launcher and not self.ready:
            elapsed = time.monotonic() - self.launcher.phase_at
            detail = translate(self.launcher.phase_key) + f" · {elapsed:.1f}s" + ("\n" + detail if detail else "")
            if self.launcher.retry_until is not None:
                detail += "\n" + translate("backoff") + f" · {max(0, self.launcher.retry_until-time.monotonic()):.1f}s"
        self.progress_label.configure(text=detail + suffix, wraplength=max(self.unit, self.progress_label.winfo_width()))
        if detail:
            self.progress_label.grid()
        else:
            self.progress_label.grid_remove()
        message = translate(self.notice_key) if self.notice_key else ""
        if self.reason:
            message = (message + " · " if message else "") + local_message(self.reason, language)
        self.notice.configure(text=message)
        if message:
            self.notice.grid()
        else:
            self.notice.grid_remove()

    def pump(self):
        for event in self.mailbox.drain():
            if event.get("generation") == self.generation:
                self.handle(event)
                try:
                    if not self.root.winfo_exists():
                        return
                except self.tk.TclError:
                    return
        if self.closing and self.launcher and not self.launcher.thread.is_alive():
            self.launcher.activity.close()
            self.destroy()
            return
        self.refresh()
        self.root.after(max(1, int(math.sqrt(tick()) * 1000)), self.pump)

    def animate(self):
        now = time.monotonic()
        delta = now - self.last_draw
        self.last_draw = now
        self.phase += delta * math.tau / max(1, math.sqrt(os.cpu_count() or 1))
        self.level *= math.exp(-delta)
        self.orb.delete("all")
        width, height = self.orb.winfo_width(), self.orb.winfo_height()
        center_x, center_y = width/2, height/2
        radius = min(width, height) * .31
        active = self.session_id is not None and not self.ending
        for index in range(3):
            size = radius * (1 + index*.19 + .035*math.sin(self.phase+index))
            self.orb.create_oval(center_x-size, center_y-size, center_x+size, center_y+size, outline=self.palette["accent"] if index == 0 else self.palette["border"], width=2 if index == 0 else 1)
        count = max(5, int(radius/self.unit)*4+1)
        for index in range(count):
            x = center_x + (index-(count-1)/2)*radius*1.4/count
            envelope = max(.1, math.cos((index-(count-1)/2)/count*math.pi))
            movement = (.2 + math.sqrt(self.level)*2) if active else .13
            amplitude = radius * envelope * (movement * (.5+.5*math.sin(self.phase*3+index*.7)) + .08)
            self.orb.create_line(x, center_y-amplitude, x, center_y+amplitude, fill=self.palette["accent"] if active else self.palette["lavender"], width=max(1, self.unit//3), capstyle="round")
        interval = max(tick(), 1 / max(1, min(60, math.sqrt(os.cpu_count() or 1)*10)))
        self.root.after(max(1, int(interval*1000)), self.animate)


def main():
    if len(sys.argv) == 3 and sys.argv[1] == "--engine":
        engine_entry(sys.argv[2])
        return
    try:
        import tkinter as tk
        from tkinter import messagebox
        root = tk.Tk()
    except Exception:
        sys.stderr.write(tr("no_display", "中文") + " / " + tr("no_display", "English") + "\n")
        return
    try:
        YuanApp(root)
        root.mainloop()
    except Exception as exc:
        try:
            messagebox.showerror(APP_NAME, concise_error(exc), parent=root)
        finally:
            root.destroy()

if __name__ == "__main__":
    main()
